## Header and Project Context
# NEXT_runner_003 — CSMMinesMagnets

## Continuation from Runner 002

**Project**: CSMMinesMagnets — Chilean Magnetic Minerals Brokerage Intelligence
**Branch**: `kilo/starry-module-9mu` (tracking origin/main)
**Created**: 2026-10-22
**Runner 001 Completed**: 2026-10-24 (Phase 1: DOC-01, DOC-02, DOC-03)
**Runner 002 Completed**: 2026-10-24 (Phase 2a: DOC-04)
**Status**: Runner 003 — Phase 2 Brokerage Protocol Continue (DOC-05, DOC-06)

---

## Current Project State
## 📍 CURRENT PROJECT STATE (as of 2026-10-24)

### ✅ COMPLETE — Phase 1 Foundation Research (Runner 001)
| Doc | Title | Chapters | Lines | Status |
|-----|-------|----------|-------|--------|
| **DOC-01** | Chilean Magnetic Mineral Landscape | 10 | 699+ | ✅ Chunked, verified, compressed, intros |
| **DOC-02** | Lives of the Extractors | 9 | 509+ | ✅ Chunked, verified, compressed, intros |
| **DOC-03** | Mutual Benefit Frameworks | 8 | 1,039 | ✅ Chunked, verified, compressed, intros |

### ✅ COMPLETE — Phase 2a Brokerage Protocol (Runner 002)
| Doc | Title | Chapters | Lines | Status |
|-----|-------|----------|-------|--------|
| **DOC-04** | Brokerage Protocol — Facilitator to Owner Transition | 9 | 1,273 | ✅ Chunked, verified, compressed, intros |

### Research Assets Ingested (All Available)
| Asset | Path | Key Data |
|-------|------|----------|
| CSMEval25 | `CSMReach/CSMEval/25-Rare-Earth-Critical-Minerals-Mining-and-Magnet-Industry/` | Industry landscape, Niron, MP Materials, Aegis-Forge |
| CSMGlobal-037-Chile | `CSMReach/CSMGeneralOutreach-Global/CSMGlobal-037-Chile/` | Grid vulnerability, mining exposure, Carrington threat |
| E172-NationalMining | `CSMReach/CSMEmailOutgoing/July2026/BATCH-16-Untapped-Sectors/E172-NationalMining.md` | Aegis-Forge specs: 17-stage, 500kg/cycle, $4.32/kg OPEX |
| **CSMMagEco2026 V2.0** | `CSMPro/CSMMag/CSMMagEco2026 New US Magnet Companies Identified/` | 12+ US magnet startups, DFARS 2027, Fe₁₆N₂ 27 MGOe |
| **CSMMagTech2026 V2.0** | `CSMPro/CSMMag/CSMMagTech 2026 Rare-Earth-Free Magnet Research/` | Fe₁₆N₂ 27 MGOe, MnBi 14 MGOe, MXene-NdFeB +12% Hci |

---

## Next Actions - Phase 2b & 2c (Runner 003 Priority)
## 🔄 NEXT — Remaining Phase 2 Documents

| Doc | Title | Priority | Est. Effort |
|-----|-------|----------|-------------|
| **DOC-05** | Tardigradia Holding Company — Venture Structure & Governance | **RUNNER 003 PRIORITY 1** | 6-8 hours |
| **DOC-06** | Chilean Critical Minerals Diplomacy — State-to-State Frameworks | **RUNNER 003 PRIORITY 2** | 6-8 hours |

---

## DOC-05 Authoring Guidance
## 🎯 DOC-05 — Tardigradia Holding Company: Venture Structure & Governance

### Scope
Complete venture structure for Tardigradia: multi-jurisdiction holding architecture, capital stack, governance, state partnership, community equity, IP strategy, and exit alignment.

### Key Sections (Target 8-10 Chapters)

1. **Multi-Jurisdiction Holding Architecture** — Delaware LP / Cayman LP → Tardigradia Chile SpA → Opco SpAs
2. **Capital Stack & Fundraising Sequence** — Pre-seed (ACS/CSM), Seed (Corfo Ventures, angels), Series A (strategic: MP Materials, Electron Energy), Series B (institutional), Project finance (Aegis-Forge clusters)
3. **Governance Architecture** — Board composition, veto rights, committee structure, community directors, state observer
4. **Community Equity Structure** — FBC trusts, vesting, anti-dilution, tag-along, dividend preferences
5. **IP Strategy & Technology Licensing** — Aegis-Forge license from ACS, CSM motor IP, Chilean patent filings, trade secret protection
6. **State Partnership Framework** — CORFO equity, Ministerio de Minería MOU, ProChile export promotion, BancoEstado green bonds
7. **Exit Alignment & Liquidity** — IPO path (NYSE/NASDAQ), trade sale (strategic), secondary (GP-led), community protection in all scenarios
8. **Risk Management & Compliance** — FCPA, Chilean anti-corruption, ESG reporting (TCFD, SASB), sanctions screening
9. **Traceability Matrix** — Every structure element traced to legal authority, DOC-03/04, CSMMag docs

### Required Data Points (Per Chapter)
- Legal citations: Delaware LP Act, Cayman ELP Law, Law 20,190 (SpA), Law 18,046 (SA)
- Capital stack: Amounts, valuations, terms, waterfall preferences
- Governance: Board seats, veto thresholds, committee charters
- Community equity: Vesting schedules, anti-dilution formulas, dividend math
- IP: License terms, patent strategy, trade secret registry
- State partnerships: CORFO term sheet, MinMin MOU, ProChile agreement
- Exit: IPO readiness timeline, strategic buyer universe, community protection mechanics

---

## DOC-06 Authoring Guidance
## 🎯 DOC-06 — Chilean Critical Minerals Diplomacy

### Scope
State-to-state frameworks for Chilean magnetic minerals: US-Chile critical minerals agreement, EU CRMA alignment, DFARS 2027 compliance, APEC/CPTPP mineral trade, technology transfer agreements.

### Key Sections (Target 8-10 Chapters)

1. **US-Chile Critical Minerals Agreement** — Executive agreement vs. treaty, DFARS 2027 compliance path, Fe₁₆N₂ qualification, IRA 45X credit eligibility
2. **EU Critical Raw Materials Act (CRMA) Alignment** — Strategic project designation, permitting acceleration, recycling targets, Chilean magnet export to EU
3. **APEC/CPTPP Mineral Trade Facilitation** — Tariff elimination, rules of origin for magnets, regulatory cooperation, digital trade
4. **Technology Transfer Frameworks** — Aegis-Forge localization, joint R&D with US national labs (ARPA-E, CMI), Chilean university partnerships
5. **Investment Protection & Dispute Settlement** — Chile-US BIT (pending), CPTPP ISDS, domestic courts, community consent as investment condition
6. **Environmental & Social Standards Harmonization** — Equator Principles, IFC Performance Standards, OECD Due Diligence, Chilean SEIA equivalence
7. **Workforce Mobility & Skills Recognition** — Mutual recognition of magnet manufacturing certifications, visa pathways for technical talent
8. **Intellectual Property & Data Governance** — Patent prosecution highways, trade secret protection, data localization, cybersecurity standards
9. **Traceability Matrix** — Every diplomatic commitment traced to treaty text, DOC-01/02/03/04/05, CSMMag docs

---

## Quality Gates (All Documents)
| Gate | Target | Verification |
|------|--------|--------------|
| Lines | ≥900 | `wc -l` |
| Formulas/Technical specs | ≥20 | `grep -c "\$\|\[" ` |
| Cross-references | ≥15 | `grep -c "Research\|DOC-\|CSM\|Chile\|Sernageomin\|Cochilco" ` |
| Standards cited | ≥8 | `grep -ci "ISO\|IEC\|ASTM\|NIJ\|MIL-STD\|DOE\|CFR\|Chilean" ` |
| Conflation flags | 0 | `grep -ic "duplicate\|contradict\|overlap" ` |
| TBD markers | Documented | `grep -c "TBD:RESEARCH" ` |
| Traceability Matrix | Present | `grep -c "Traceability Matrix" ` |
| Chunk reassembly diff | 0 bytes | `python3 ../../__Python_Tools/write_large_file.py concat chunks/DOC-XX /tmp/test.md && diff FinishedWork/DOC-XX_*.md /tmp/test.md` |
| Manifest checksums | PASS | `python3 ../../__Python_Tools/write_large_file.py verify chunks/DOC-XX` |
| Heuristic intros | 4 variants | `ls intros/DOC-XX_*_intro_*.md | wc -l` |

---

## Git Workflow
```bash
# After each document complete
git add chunks/DOC-XX/ FinishedWork/DOC-XX_*.md.gz intros/DOC-XX*
git commit -m "runner003: DOC-XX complete - chunked, verified, compressed, heuristic intros generated"
```

---

## Next Runner Handoff
Create NEXT_runner_004.md with:
- Completed documents list (DOC-01 through DOC-06)
- Next batch assignments (DOC-07 through DOC-12)
- Infrastructure status
- Any blockers or decisions

---

*This NEXT_runner_003 reflects actual progress: Phase 1 complete (DOC-01, DOC-02, DOC-03), Phase 2a complete (DOC-04). Execute Phase 2b/2c (DOC-05, DOC-06) immediately upon session start.*
