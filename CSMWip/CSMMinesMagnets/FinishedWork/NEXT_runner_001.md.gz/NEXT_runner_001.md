## Header and Project Context
# NEXT_runner_001 — CSMMinesMagnets

## Continuation from Project Initialization

**Project**: CSMMinesMagnets — Chilean Magnetic Minerals Brokerage Intelligence
**Branch**: `kilo/csm-mines-magnets` (tracking origin/main)
**Created**: 2026-10-22
**Status**: Runner 001 — Phase 1 Foundation Research Start (DOC-01, DOC-02, DOC-03)

---



## Current Project State
## 📍 CURRENT PROJECT STATE (as of 2026-10-22)

### ✅ COMPLETE — Project Initialization

#### Infrastructure (Complete)
- **Directory Structure**: Created per AGENTS.md specification
- **AGENTS.md**: Complete project conventions, 60-doc pipeline defined
- **HEARTBEAT_MAGNETS.md**: 120s interval config written
- **write_large_file.py Pipeline**: Verified operational (IncrementalDocumentWriter class)
- **Heartbeat Monitor**: scripts/heartbeat_monitor.py ready
- **Task Timer**: scripts/task_timer.py ready (30s guard)

#### Research Assets Ingested
| Asset | Path | Key Data Extracted |
|-------|------|-------------------|
| CSMEval25 Rare Earth Mining | `CSMReach/CSMEval/25-Rare-Earth-Critical-Minerals-Mining-and-Magnet-Industry/` | Industry landscape, Niron Magnetics, MP Materials, Aegis-Forge ref |
| Chile Outreach Briefing | `CSMReach/CSMGeneralOutreach-Global/CSMGlobal-037-Chile/` | Grid vulnerability, mining exposure, Carrington-class threat |
| Chile Email Outreach | `CSMReach/CSMEmailOutgoing/July2026/BATCH-08-Global-Outreach/E-GLOBAL-chile.md` | Distribution channel, contact framework |
| National Mining Association | `CSMReach/CSMEmailOutgoing/July2026/BATCH-16-Untapped-Sectors/E172-NationalMining.md` | Acid-free REE processing, Aegis-Forge specs, CAPEX/OPEX |
| **CSMMagEco2026 V2.0** | `CSMPro/CSMMag/CSMMagEco2026 New US Magnet Companies Identified/` | **12+ domestic magnet startups, DFARS 2027 Jan deadline, Fe₁₆N₂ 27 MGOe production, SmCo Electron Energy, Urban Mining HPMS 12t/mo, MP Materials Fort Worth, Noveon DFARS-qualified** |
| **CSMMagTech2026 V2.0** | `CSMPro/CSMMag/CSMMagTech 2026 Rare-Earth-Free Magnet Research/` | **Fe₁₆N₂ 27 MGOe, MnBi 14 MGOe, AlNiCo 10.5 MGOe (AM), Fe-Sn 12 MGOe (NIMS), MXene-NdFeB +12% Hci, EU CRMA 2024, CSM portfolio magnet strategy table** |
| Aegis-Forge Separator | `CSMFAB/CSMFAB0108/` (referenced) | Thermal cascade inductive separation, 17-stage, zero liquid waste |

#### Git
- Repository initialized at `/workspace/app/CSMWip/CSMMinesMagnets`
- Initial commit pending

---



## Next Actions - Phase 1 Foundation Research
## 🔄 NEXT — Phase 1 Foundation Research (Runner 001 Priority)

| Doc | Title | Priority | Est. Effort |
|-----|-------|----------|-------------|
| **DOC-01** | Chilean Magnetic Mineral Landscape — Geological Survey & Resource Mapping | **RUNNER 001 PRIORITY 1** | 6-8 hours |
| **DOC-02** | Lives of the Extractors — Community Ethnography & Human Geography | **RUNNER 001 PRIORITY 2** | 6-8 hours |
| **DOC-03** | Mutual Benefit Frameworks — Value Return to Chilean Communities | **RUNNER 001 PRIORITY 3** | 6-8 hours |

---



## Execution Strategy
## 🚀 EXECUTION STRATEGY — INCREMENTAL CHAPTER PIPELINE

### Pipeline Per Document


### Session Structure (Adapted for 2-min Heartbeat)
- **Station**: Author 1 chapter (target 15-30 min per chapter)
- **Coupling**: Write → Verify → Compress → Commit (2 min)
- **Heartbeat**: Terminal progress update every 120 seconds
- **Subtask Guard**: 30 seconds max — auto-split if exceeded
- **Auto-continue**: Queue next subtask immediately, no blocking
- **Velocity Target**: ≥3 chapters/hour (faster than monolithic write)

---



## Quality Gates
## 🎯 QUALITY GATES — EVERY DOCUMENT MUST PASS

| Gate | Target | Verification |
|------|--------|--------------|
| Lines | ≥900 | `wc -l` |
| Formulas/Technical specs (LaTeX/Unicode) | ≥20 | `grep -c "\$\|\[" ` |
| Cross-references | ≥15 | `grep -c "Research\|DOC-\|CSM\|Chile\|Sernageomin\|Cochilco" ` |
| Standards cited | ≥8 | `grep -ci "ISO\|IEC\|ASTM\|NIJ\|MIL-STD\|DOE\|CFR\|Chilean" ` |
| Conflation flags | 0 | `grep -ic "duplicate\|contradict\|overlap" ` |
| TBD markers | Documented | `grep -c "TBD:RESEARCH" ` |
| Traceability Matrix | Present | `grep -c "Traceability Matrix" ` |
| Chunk reassembly diff | 0 bytes | `python3 ../../__Python_Tools/write_large_file.py concat chunks/DOC-XX /tmp/test.md && diff FinishedWork/DOC-XX_*.md /tmp/test.md` |
| Manifest checksums | PASS | `python3 ../../__Python_Tools/write_large_file.py verify chunks/DOC-XX` |
| Heuristic intros | 4 variants | `ls intros/DOC-XX_*_intro_*.md | wc -l` |

---



## Key Reference Documents
## 📚 KEY REFERENCE DOCUMENTS (Always Available)

| Document | Path | Purpose |
|----------|------|---------|
| CSMMagEco2026 V2.0 | `/workspace/app/CSMPro/CSMMag/CSMMagEco2026 New US Magnet Companies Identified/CSMMagEco2026 New US Magnet Companies Identified V2.0.md` | US magnet startup ecosystem, DFARS 2027, Fe₁₆N₂ 27 MGOe |
| CSMMagTech2026 V2.0 | `/workspace/app/CSMPro/CSMMag/CSMMagTech 2026 Rare-Earth-Free Magnet Research/CSMMagTech 2026 Rare-Earth-Free Magnet Research V2.0.md` | Rare-earth-free magnet performance table, MXene-NdFeB, CRMA, portfolio strategy |
| CSMEval25 | `/workspace/app/CSMReach/CSMEval/25-Rare-Earth-Critical-Minerals-Mining-and-Magnet-Industry/` | Industry baseline, Niron, MP Materials, Aegis-Forge |
| CSMGlobal-037-Chile | `/workspace/app/CSMReach/CSMGeneralOutreach-Global/CSMGlobal-037-Chile/CSMGlobal-037-Chile-Outreach.md` | Chile grid vulnerability, mining exposure |
| E172-NationalMining | `/workspace/app/CSMReach/CSMEmailOutgoing/July2026/BATCH-16-Untapped-Sectors/E172-NationalMining.md` | Aegis-Forge acid-free REE processing specs |
| Chilean Mining Code | Law 18,248 + modifications | Legal framework for concessions, royalties |
| Sernageomin Datasets | `https://www.sernageomin.cl/` | Geological maps, mineral occurrences, production stats |
| Cochilco Reports | `https://www.cochilco.cl/` | Copper/lithium market intelligence, price forecasts |
| USGS Mineral Summaries | `https://pubs.usgs.gov/` | Chile chapters: Cu, Li, REE, Fe production/reserves |
| Indigenous Law 19,253 | `https://www.bcn.cl/leychile/` | Consulta indígena, territorial rights |
| Environmental Law 19,300 | `https://www.bcn.cl/leychile/` | SEIA/RCA permitting, impact assessment |

---



## Handoff Protocol
## 🔄 HANDOFF PROTOCOL — RUNNER 001 END

At session end, create NEXT_runner_002.md:



---



## Golden Rules
## ⚡ GOLDEN RULES (Runner 001)

1. **NO CONFLATION** — Each document addresses distinct territory; cross-reference, do not duplicate
2. **NO GUESSING** — Every value sourced from Sernageomin, Cochilco, USGS, company reports, or [TBD:RESEARCH]
3. **MATHEMATICAL RIGOR** — SI units, LaTeX formulas, derivations shown for reserve calculations, grades, economics
4. **TRACEABILITY** — Every spec traces to Research/ index, CSMMag docs, or Chilean primary sources
5. **LOGICAL CHAPTERS** — Split by geological district, community, mineral, or framework — NOT arbitrary pieces
6. **HEARTBEAT EVERY 2 MIN** — `python3 scripts/heartbeat_monitor.py --interval 120`
7. **SUBTASK ≤ 30 SEC** — Split chapter further if exceeded
8. **VERIFY CHUNKS** — `write_large_file.py verify` = PASS
9. **AUTO-CONTINUE** — No blocking, queue next immediately
10. **COMMIT OFTEN** — After each chapter complete
11. **HEURISTIC INTROS** — Every document gets Williams/Keymaker/El Segundo/Baker Street/SHIELD variants
12. **CHILE FIRST** — All analysis framed for Chilean context, Chilean beneficiaries, Chilean sovereignty

---



## Subtask Queue
## 📋 RUNNER 001 SUBTASK QUEUE

| # | Subtask | Est. Time | Dependencies |
|---|---------|-----------|--------------|
| 1 | Research ingestion: CSMMagEco2026 V2.0, CSMMagTech2026 V2.0, CSMEval25 | 60 min | Source documents |
| 2 | Research ingestion: CSMGlobal-037-Chile, E172-NationalMining | 30 min | Source documents |
| 3 | Research ingestion: Chilean Mining Code, Sernageomin, Cochilco, USGS | 60 min | Web/Gov sources |
| 4 | Outline DOC-01: Geological framework, districts, minerals, infrastructure | 30 min | Research complete |
| 5 | Write DOC-01 Chapter 1: Geological Framework of Chile | 45 min | Outline |
| 6 | Write DOC-01 Chapter 2: Iron Oxide Copper Gold (IOCG) Belt | 45 min | Ch 1 |
| 7 | Write DOC-01 Chapter 3: Iron Oxide Apatite (IOA) / Kiruna-type | 45 min | Ch 1 |
| 8 | Write DOC-01 Chapter 4: Porphyry Cu-Mo Magnetic Byproducts | 45 min | Ch 1 |
| 9 | Write DOC-01 Chapter 5: REE Occurrences in Atacama | 45 min | Ch 1 |
| 10 | Write DOC-01 Chapter 6: Current Production & Processing Status | 45 min | Ch 2-5 |
| 11 | Write DOC-01 Chapter 7: Infrastructure Mapping (Rail, Ports, Grid, Water) | 45 min | Ch 6 |
| 12 | Write DOC-01 Chapter 8: Aegis-Forge Integration Opportunities | 30 min | Ch 6-7, E172 |
| 13 | Write DOC-01 Chapter 9: Carrington Storm Motors Magnet Spec Alignment | 30 min | Ch 8, CSMMag docs |
| 14 | Write DOC-01 Chapter 10: Strategic Recommendations & Traceability Matrix | 30 min | Ch 1-9 |
| 15 | Chunk, verify, compress DOC-01 | 15 min | write_large_file.py |
| 16 | Generate heuristic intros for DOC-01 | 10 min | generate_heuristic_intros.sh |
| 17-30 | Repeat for DOC-02 (Community Ethnography) | ~5 hrs | DOC-01 complete |
| 31-45 | Repeat for DOC-03 (Mutual Benefit Frameworks) | ~5 hrs | DOC-02 complete |
| 46 | Verify all 3 document chunks + manifests | 10 min | write_large_file.py |
| 47 | Update master index: chunks/MASTER_INDEX.json | 5 min | Python script |
| 48 | Create NEXT_runner_002.md handoff | 10 min | Template |
| 49 | Git commit all changes | 5 min | git |
| 50 | Tag runner-001-complete | 1 min | git tag |

---



## DOC-01 Authoring Guidance
## 🎯 DOC-01 AUTHORING GUIDANCE — Chilean Magnetic Mineral Landscape

### Scope
Comprehensive geological survey of Chiles magnetic mineral endowment, mapped to Carrington Storm Motors magnet specifications and Tardigradia venture requirements.

### Key Sections (10 Chapters Target)

1. **Geological Framework of Chile** — Andean metallogeny, tectonic settings, metallogenic belts
2. **Iron Oxide Copper Gold (IOCG) Belt** — El Romeral, El Algarrobo, Candelaria, Manto Verde; magnetite grades, Fe/Cu/Au ratios
3. **Iron Oxide Apatite (IOA) / Kiruna-type** — Los Colorados, Algarrobo, Cerro Negro Norte; massive magnetite, P/REE associations
4. **Porphyry Cu-Mo Magnetic Byproducts** — Chuquicamata, Escondida, Los Bronces, El Teniente; pyrrhotite/magnetite in skarn/alteration halos
5. **REE Occurrences in Atacama** — Carrizalillo, Sierra Moreno, rare earth element prospects in IOCG/IOA systems
6. **Current Production & Processing Status** — CAP magnetite concentrate (68% Fe), Codelco magnetite byproduct, REE recovery rates (near zero currently)
7. **Infrastructure Mapping** — FCAB rail, Puerto Antofagasta/Mejillones/San Antonio/Coronel/Punta Arenas, SING/SIC grid, water rights
8. **Aegis-Forge Integration Opportunities** — Thermal cascade separation at mine sites vs. central hub; 17-stage vs. conventional magnetic separation
9. **Carrington Storm Motors Magnet Spec Alignment** — Map Chilean Fe/REE output to NdFeB, SmCo, Fe₁₆N₂, FeCo grade requirements
10. **Strategic Recommendations & Traceability Matrix** — Priority districts, partnership models, regulatory pathway, TBD flags

### Required Data Points (Per Chapter)
- Reserves/Resources (JORC/NI 43-101): Tonnes, Fe%, Cu%, Au g/t, REO ppm
- Mineralogy: Magnetite/hematite/goethite/pyrrhotite percentages, liberation size
- Processing: Current flow sheet, recovery %, concentrate grade, tailings disposition
- Economics: CAPEX/OPEX per tonne, transport to port, power cost, water cost
- Magnetics: Saturation magnetization (emu/g), coercivity, Curie temp where measured
- Cross-refs: Sernageomin bulletin #, Cochilco report year, company annual report page

### Standards to Cite
- Chilean Mining Code (Law 18,248), Indigenous Law (19,253), Environmental Law (19,300)
- JORC Code / NI 43-101 (resource reporting)
- ISO 11323 (iron ore sampling), ISO 3082 (iron ore chemical analysis)
- ASTM E877 (iron ore sampling practice)
- CSMMagEco2026 (DFARS 2027, Fe16N2 27 MGOe), CSMMagTech2026 (rare-earth-free performance table)
- MIL-STD-1540 (test requirements for magnet acceptance)

---

*This NEXT_runner_001 reflects actual progress: Project initialized, infrastructure operational, research assets ingested. Execute immediately upon session start.*


