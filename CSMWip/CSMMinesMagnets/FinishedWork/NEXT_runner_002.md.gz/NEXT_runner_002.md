## Header and Project Context
# NEXT_runner_002 — CSMMinesMagnets

## Continuation from Runner 001

**Project**: CSMMinesMagnets — Chilean Magnetic Minerals Brokerage Intelligence
**Branch**: `kilo/starry-module-9mu` (tracking origin/main)
**Created**: 2026-10-22
**Runner 001 Completed**: 2026-10-24
**Status**: Runner 002 — Phase 1 Foundation Research Complete, Phase 2 Brokerage Protocol Start

---

## Current Project State
## 📍 CURRENT PROJECT STATE (as of 2026-10-24)

### ✅ COMPLETE — Phase 1 Foundation Research (Runner 001)

#### Infrastructure (Complete)
- **Directory Structure**: Created per AGENTS.md specification
- **AGENTS.md**: Complete project conventions, 60-doc pipeline defined
- **HEARTBEAT_MAGNETS.md**: 120s interval config written
- **write_large_file.py Pipeline**: Verified operational (IncrementalDocumentWriter class)
- **Heartbeat Monitor**: scripts/heartbeat_monitor.py ready
- **Task Timer**: scripts/task_timer.py ready (30s guard)
- **Heuristic Intros Generator**: scripts/generate_heuristic_intros.sh adapted and working

#### Documents Complete (3/60)
| Doc | Title | Chapters | Lines | Status |
|-----|-------|----------|-------|--------|
| **DOC-01** | Chilean Magnetic Mineral Landscape — Geological Survey & Resource Mapping | 10 | 699+ | ✅ Chunked, verified, compressed, intros generated |
| **DOC-02** | Lives of the Extractors — Community Ethnography & Human Geography | 9 | 509+ | ✅ Chunked, verified, compressed, intros generated |
| **DOC-03** | Mutual Benefit Frameworks — Value Return to Chilean Communities | 8 | 1,039 | ✅ Chunked, verified, compressed, intros generated |

#### Research Assets Ingested
| Asset | Path | Key Data Extracted |
|-------|------|-------------------|
| CSMEval25 Rare Earth Mining | `CSMReach/CSMEval/25-Rare-Earth-Critical-Minerals-Mining-and-Magnet-Industry/` | Industry landscape, Niron Magnetics, MP Materials, Aegis-Forge ref |
| Chile Outreach Briefing | `CSMReach/CSMGeneralOutreach-Global/CSMGlobal-037-Chile/` | Grid vulnerability, mining exposure, Carrington-class threat |
| Chile Email Outreach | `CSMReach/CSMEmailOutgoing/July2026/BATCH-08-Global-Outreach/E-GLOBAL-chile.md` | Distribution channel, contact framework |
| National Mining Association | `CSMReach/CSMEmailOutgoing/July2026/BATCH-16-Untapped-Sectors/E172-NationalMining.md` | Acid-free REE processing, Aegis-Forge specs, CAPEX/OPEX |
| **CSMMagEco2026 V2.0** | `CSMPro/CSMMag/CSMMagEco2026 New US Magnet Companies Identified/` | **12+ domestic magnet startups, DFARS 2027 Jan deadline, Fe₁₆N₂ 27 MGOe production, SmCo Electron Energy, Urban Mining HPMS 12t/mo, MP Materials Fort Worth, Noveon DFARS-qualified** |
| **CSMMagTech2026 V2.0** | `CSMPro/CSMMag/CSMMagTech 2026 Rare-Earth-Free Magnet Research/` | **Fe₁₆N₂ 27 MGOe, MnBi 14 MGOe, AlNiCo 10.5 MGOe (AM), Fe-Sn 12 MGOe (NIMS), MXene-NdFeB +12% Hci, EU CRMA 2024, CSM portfolio magnet strategy table** |
| Aegis-Forge Separator | `CSMFAB/CSMFAB0108/` (referenced) | Thermal cascade inductive separation, 17-stage, zero liquid waste |

#### Git
- Repository initialized at `/workspace/app/CSMWip/CSMMinesMagnets`
- Commit b3c07dcc2: "runner001: DOC-03 complete - chunked, verified, compressed, heuristic intros generated"
- Tag: runner-001-complete (to be created)

---

## Next Actions - Phase 2 Brokerage Protocol
## 🔄 NEXT — Phase 2 Brokerage Protocol (Runner 002 Priority)

| Doc | Title | Priority | Est. Effort |
|-----|-------|----------|-------------|
| **DOC-04** | Brokerage Protocol — Facilitator to Owner Transition Mechanics | **RUNNER 002 PRIORITY 1** | 6-8 hours |
| **DOC-05** | Tardigradia Holding Company — Venture Structure & Governance | **RUNNER 002 PRIORITY 2** | 6-8 hours |
| **DOC-06** | Chilean Critical Minerals Diplomacy — State-to-State Frameworks | **RUNNER 002 PRIORITY 3** | 6-8 hours |

---

## Execution Strategy
## 🚀 EXECUTION STRATEGY — INCREMENTAL CHAPTER PIPELINE

### Pipeline Per Document


### Session Structure (Adapted for 2-min Heartbeat)
- **Station**: Author 1 chapter (target 15-30 min per chapter)
- **Coupling**: Write → Verify → Compress → Commit (2 min)
- **Heartbeat**: Terminal progress update every 120 seconds
- **Subtask Guard**: 30 seconds max — auto-split if exceeded
- **Auto-continue**: Queue next subtask immediately, no blocking
- **Velocity Target**: ≥3 chapters/hour (faster than monolithic write)

---

## Quality Gates
## 🎯 QUALITY GATES — EVERY DOCUMENT MUST PASS

| Gate | Target | Verification |
|------|--------|--------------|
| Lines | ≥900 | `wc -l` |
| Formulas/Technical specs (LaTeX/Unicode) | ≥20 | `grep -c "\$\|\[" ` |
| Cross-references | ≥15 | `grep -c "Research\|DOC-\|CSM\|Chile\|Sernageomin\|Cochilco" ` |
| Standards cited | ≥8 | `grep -ci "ISO\|IEC\|ASTM\|NIJ\|MIL-STD\|DOE\|CFR\|Chilean" ` |
| Conflation flags | 0 | `grep -ic "duplicate\|contradict\|overlap" ` |
| TBD markers | Documented | `grep -c "TBD:RESEARCH" ` |
| Traceability Matrix | Present | `grep -c "Traceability Matrix" ` |
| Chunk reassembly diff | 0 bytes | `python3 ../../__Python_Tools/write_large_file.py concat chunks/DOC-XX /tmp/test.md && diff FinishedWork/DOC-XX_*.md /tmp/test.md` |
| Manifest checksums | PASS | `python3 ../../__Python_Tools/write_large_file.py verify chunks/DOC-XX` |
| Heuristic intros | 4 variants | `ls intros/DOC-XX_*_intro_*.md | wc -l` |

---

## Key Reference Documents (Extended for Runner 002)
## 📚 KEY REFERENCE DOCUMENTS (Always Available)

| Document | Path | Purpose |
|----------|------|---------|
| **DOC-01** | `FinishedWork/DOC-01_Chilean_Magnetic_Mineral_Landscape.md.gz` | Geological framework, districts, Aegis-Forge integration |
| **DOC-02** | `FinishedWork/DOC-02_Lives_of_the_Extractors.md.gz` | Community ethnography, social license, NGO landscape |
| **DOC-03** | `FinishedWork/DOC-03_Mutual_Benefit_Frameworks.md.gz` | Royalty regime, community agreements, equity, workforce, governance |
| CSMMagEco2026 V2.0 | `/workspace/app/CSMPro/CSMMag/CSMMagEco2026 New US Magnet Companies Identified/CSMMagEco2026 New US Magnet Companies Identified V2.0.md` | US magnet startup ecosystem, DFARS 2027, Fe₁₆N₂ 27 MGOe |
| CSMMagTech2026 V2.0 | `/workspace/app/CSMPro/CSMMag/CSMMagTech 2026 Rare-Earth-Free Magnet Research/CSMMagTech 2026 Rare-Earth-Free Magnet Research V2.0.md` | Rare-earth-free magnet performance table, portfolio strategy |
| CSMEval25 | `/workspace/app/CSMReach/CSMEval/25-Rare-Earth-Critical-Minerals-Mining-and-Magnet-Industry/` | Industry baseline, Niron, MP Materials, Aegis-Forge |
| CSMGlobal-037-Chile | `/workspace/app/CSMReach/CSMGeneralOutreach-Global/CSMGlobal-037-Chile/CSMGlobal-037-Chile-Outreach.md` | Chile grid vulnerability, mining exposure |
| E172-NationalMining | `/workspace/app/CSMReach/CSMEmailOutgoing/July2026/BATCH-16-Untapped-Sectors/E172-NationalMining.md` | Aegis-Forge acid-free REE processing specs |
| Chilean Mining Code | Law 18,248 + modifications | Legal framework for concessions, royalties |
| Royalty Minera Law 21,210 | Law 21,210 (2023) | New royalty regime, distribution formula |
| Indigenous Law 19,253 | `https://www.bcn.cl/leychile/` | Consulta indígena, territorial rights |
| Environmental Law 19,300 | `https://www.bcn.cl/leychile/` | SEIA/RCA permitting, impact assessment |

---

## Handoff Protocol
## 🔄 HANDOFF PROTOCOL — RUNNER 002 END

At session end, create NEXT_runner_003.md:



---

## Golden Rules
## ⚡ GOLDEN RULES (Runner 002)

1. **NO CONFLATION** — Each document addresses distinct territory; cross-reference, do not duplicate
2. **NO GUESSING** — Every value sourced from primary sources or [TBD:RESEARCH]
3. **MATHEMATICAL RIGOR** — SI units, LaTeX formulas, derivations shown
4. **TRACEABILITY** — Every spec traces to Research/ index, CSMMag docs, or Chilean primary sources
5. **LOGICAL CHAPTERS** — Split by protocol phase, governance layer, diplomatic channel — NOT arbitrary pieces
6. **HEARTBEAT EVERY 2 MIN** — `python3 scripts/heartbeat_monitor.py --interval 120`
7. **SUBTASK ≤ 30 SEC** — Split chapter further if exceeded
8. **VERIFY CHUNKS** — `write_large_file.py verify` = PASS
9. **AUTO-CONTINUE** — No blocking, queue next immediately
10. **COMMIT OFTEN** — After each chapter complete
11. **HEURISTIC INTROS** — Every document gets Williams/Keymaker/El Segundo/Baker Street/SHIELD variants
12. **CHILE FIRST** — All analysis framed for Chilean context, Chilean beneficiaries, Chilean sovereignty

---

## Subtask Queue
## 📋 RUNNER 002 SUBTASK QUEUE

| # | Subtask | Est. Time | Dependencies |
|---|---------|-----------|--------------|
| 1 | Research ingestion: DOC-01, DOC-02, DOC-03 key findings | 45 min | Previous docs |
| 2 | Research ingestion: Brokerage models, venture structures, diplomacy frameworks | 45 min | External sources |
| 3 | Outline DOC-04: Brokerage protocol phases, transition mechanics, legal framework | 30 min | Research complete |
| 4 | Write DOC-04 Chapter 1: Brokerage Mandate & Legal Basis | 45 min | Outline |
| 5 | Write DOC-04 Chapter 2: Facilitator Role Definition & Scope | 45 min | Ch 1 |
| 6 | Write DOC-04 Chapter 3: Owner Transition Trigger Conditions | 45 min | Ch 2 |
| 7 | Write DOC-04 Chapter 4: Valuation Methodology for Transition | 45 min | Ch 3 |
| 8 | Write DOC-04 Chapter 5: Transition Execution Mechanics | 45 min | Ch 4 |
| 9 | Write DOC-04 Chapter 6: Post-Transition Governance | 45 min | Ch 5 |
| 10 | Write DOC-04 Chapter 7: Dispute Resolution & Escrow | 30 min | Ch 6 |
| 11 | Write DOC-04 Chapter 8: Cross-Border Enforcement (Chile/US) | 30 min | Ch 7 |
| 12 | Write DOC-04 Chapter 9: Traceability Matrix | 30 min | Ch 1-8 |
| 13 | Chunk, verify, compress DOC-04 | 15 min | write_large_file.py |
| 14 | Generate heuristic intros for DOC-04 | 10 min | generate_heuristic_intros.sh |
| 15-27 | Repeat for DOC-05 (Tardigradia Venture Structure) | ~5 hrs | DOC-04 complete |
| 28-40 | Repeat for DOC-06 (Critical Minerals Diplomacy) | ~5 hrs | DOC-05 complete |
| 41 | Verify all 3 document chunks + manifests | 10 min | write_large_file.py |
| 42 | Update master index: chunks/MASTER_INDEX.json | 5 min | Python script |
| 43 | Create NEXT_runner_003.md handoff | 10 min | Template |
| 44 | Git commit all changes | 5 min | git |
| 45 | Tag runner-002-complete | 1 min | git tag |

---

## DOC-04 Authoring Guidance
## 🎯 DOC-04 AUTHORING GUIDANCE — Brokerage Protocol

### Scope
Legal and operational framework for transitioning from CSM (facilitator/broker) to Tardigradia (owner/operator) of Chilean magnetic mineral assets. Defines trigger conditions, valuation methodology, execution mechanics, and post-transition governance.

### Key Sections (9 Chapters Target)

1. **Brokerage Mandate & Legal Basis** — CSM facilitator authority, Chilean brokerage law, mandate scope, termination conditions
2. **Facilitator Role Definition & Scope** — What CSM does (deal origination, due diligence, community engagement, government liaison) vs. what Tardigradia does (capital deployment, operations, processing, manufacturing)
3. **Owner Transition Trigger Conditions** — Milestone-based triggers: RCA approved, concessions secured, community agreements signed, financing committed, Aegis-Forge pilot operational
4. **Valuation Methodology for Transition** — DCF of magnetic mineral reserves, Aegis-Forge processing NPV, magnet manufacturing margin, strategic option value (DFARS 2027, Fe₁₆N₂)
5. **Transition Execution Mechanics** — Share purchase agreement, asset contribution, earnout structure, key person provisions, non-compete
6. **Post-Transition Governance** — Tardigradia board composition, CSM ongoing role (royalty, advisory), community trust integration, state observer rights
7. **Dispute Resolution & Escrow** — ICC arbitration, Chilean court enforcement, escrow for earnouts, community veto protection
8. **Cross-Border Enforcement (Chile/US)** — Delaware/Cayman holdco, Chilean SpA opcos, New York law SHA, Chilean law asset agreements, treaty arbitration
9. **Traceability Matrix** — Every clause traced to Chilean law, CSM mandate, DOC-01/02/03, Aegis-Forge specs

### Required Data Points (Per Chapter)
- Legal citations: Chilean brokerage law, corporate law, mining code, foreign investment statute
- Valuation formulas: DCF with WACC, comparable transactions, option pricing for strategic flexibility
- Trigger definitions: Binary milestones with objective verification sources
- Economics: CSM facilitator fee structure, Tardigradia capital commitment schedule, community equity vesting
- Cross-refs: DOC-01 (geology), DOC-02 (communities), DOC-03 (benefit frameworks), CSMMag docs (magnet specs)

### Standards to Cite
- Chilean Brokerage Law (Law 18,045 - Mercado de Valores)
- Chilean Corporate Law (Law 18,046 - Sociedades Anónimas; Law 20,190 - SpA)
- Mining Code (Law 18,248), Royalty Minera (Law 21,210)
- Foreign Investment (DL 600, Chapter XIV of Compendium)
- ICC Arbitration Rules 2021
- NY Convention on Foreign Arbitral Awards
- CSMMagEco2026 (DFARS 2027, strategic value), CSMMagTech2026 (Fe₁₆N₂ 27 MGOe)

---

## DOC-05 Authoring Guidance
## 🎯 DOC-05 AUTHORING GUIDANCE — Tardigradia Holding Company

### Scope
Complete venture structure for Tardigradia: multi-jurisdiction holding architecture, capital stack, governance, state partnership, community equity, IP strategy, and exit alignment.

### Key Sections (Target 8-10 Chapters)

1. **Multi-Jurisdiction Holding Architecture** — Delaware LP / Cayman LP → Tardigradia Chile SpA → Opco SpAs
2. **Capital Stack & Fundraising Sequence** — Pre-seed (ACS/CSM), Seed (Corfo Ventures, angels), Series A (strategic: MP Materials, Electron Energy), Series B (institutional), Project finance (Aegis-Forge clusters)
3. **Governance Architecture** — Board composition, veto rights, committee structure, community directors, state observer
4. **Community Equity Structure** — FBC trusts, vesting, anti-dilution, tag-along, dividend preferences
5. **IP Strategy & Technology Licensing** — Aegis-Forge license from ACS, CSM motor IP, Chilean patent filings, trade secret protection
6. **State Partnership Framework** — CORFO equity, Ministerio de Minería MOU, ProChile export promotion, BancoEstado green bonds
7. **Exit Alignment & Liquidity** — IPO path (NYSE/NASDAQ), trade sale (strategic), secondary (GP-led), community protection in all scenarios
8. **Risk Management & Compliance** — FCPA, Chilean anti-corruption, ESG reporting (TCFD, SASB), sanctions screening
9. **Traceability Matrix** — Every structure element traced to legal authority, DOC-03/04, CSMMag docs

---

## DOC-06 Authoring Guidance
## 🎯 DOC-06 AUTHORING GUIDANCE — Chilean Critical Minerals Diplomacy

### Scope
State-to-state frameworks for Chilean magnetic minerals: US-Chile critical minerals agreement, EU CRMA alignment, DFARS 2027 compliance, APEC/CPTPP mineral trade, technology transfer agreements.

### Key Sections (Target 8-10 Chapters)

1. **US-Chile Critical Minerals Agreement** — Executive agreement vs. treaty, DFARS 2027 compliance path, Fe₁₆N₂ qualification, IRA 45X credit eligibility
2. **EU Critical Raw Materials Act (CRMA) Alignment** — Strategic project designation, permitting acceleration, recycling targets, Chilean magnet export to EU
3. **APEC/CPTPP Mineral Trade Facilitation** — Tariff elimination, rules of origin for magnets, regulatory cooperation, digital trade
4. **Technology Transfer Frameworks** — Aegis-Forge localization, joint R&D with US national labs (ARPA-E, CMI), Chilean university partnerships
5. **Investment Protection & Dispute Settlement** — Chile-US BIT (pending), CPTPP ISDS, domestic courts, community consent as investment condition
6. **Environmental & Social Standards Harmonization** — Equator Principles, IFC Performance Standards, OECD Due Diligence, Chilean SEIA equivalence
7. **Workforce Mobility & Skills Recognition** — Mutual recognition of magnet manufacturing certifications, visa pathways for technical talent
8. **Intellectual Property & Data Governance** — Patent prosecution highways, trade secret protection, data localization, cybersecurity standards
9. **Traceability Matrix** — Every diplomatic commitment traced to treaty text, DOC-01/02/03/04/05, CSMMag docs

---

*This NEXT_runner_002 reflects actual progress: Phase 1 Foundation Research complete (DOC-01, DOC-02, DOC-03). Execute Phase 2 Brokerage Protocol immediately upon session start.*
