package com.carrpod.vertebrae.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.carrpod.vertebrae.R;
import com.carrpod.vertebrae.model.KilosSession;
import com.carrpod.vertebrae.model.SessionGroup;
import com.carrpod.vertebrae.storage.SessionStorageManager;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {

    private static final int OVERLAY_PERMISSION_REQUEST = 1001;
    private static final String TAG = "MainActivity";

    private SessionStorageManager storage;
    private Set<String> expandedGroups = new HashSet<>();

    private ListView lvGroups;
    private ListView lvSessions;
    private View emptyState;
    private GroupsAdapter groupsAdapter;
    private SessionsAdapter sessionsAdapter;
    private String currentGroupFilter = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        storage = SessionStorageManager.getInstance();

        setupViews();
        checkOverlayPermission();
        loadData();
    }

    private void setupViews() {
        // Groups ListView
        lvGroups = findViewById(R.id.lv_groups);
        groupsAdapter = new GroupsAdapter(
                this::onGroupClick,
                this::onGroupLongClick,
                expandedGroups);
        lvGroups.setAdapter(groupsAdapter);

        // Sessions ListView
        lvSessions = findViewById(R.id.lv_sessions);
        sessionsAdapter = new SessionsAdapter(
                this::onSessionClick,
                this::onSessionLongClick);
        lvSessions.setAdapter(sessionsAdapter);

        emptyState = findViewById(R.id.empty_state);

        // FAB
        findViewById(R.id.fab_add_session).setOnClickListener(v -> showNewSessionDialog());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_new_group) {
            showNewGroupDialog();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void loadData() {
        List<SessionGroup> groups = storage.loadAllGroups();
        groupsAdapter.submitList(groups);

        List<KilosSession> sessions;
        if (currentGroupFilter != null) {
            sessions = storage.loadSessionsByGroup(currentGroupFilter);
        } else {
            sessions = storage.loadAllSessions();
        }
        sessionsAdapter.submitList(sessions);
        updateEmptyState(sessions.isEmpty());
    }

    private void updateEmptyState(boolean isEmpty) {
        if (emptyState != null) {
            emptyState.setVisibility(isEmpty ? View.VISIBLE : View.GONE);
        }
        lvSessions.setVisibility(isEmpty ? View.GONE : View.VISIBLE);
    }

    private void onGroupClick(String groupId) {
        if (expandedGroups.contains(groupId)) {
            expandedGroups.remove(groupId);
        } else {
            expandedGroups.add(groupId);
        }
        groupsAdapter.notifyDataSetChanged();
    }

    private void onGroupLongClick(SessionGroup group) {
        showGroupOptions(group);
    }

    private void onSessionClick(KilosSession session) {
        Toast.makeText(this, getString(R.string.session_selected, session.getDisplayName()), Toast.LENGTH_SHORT).show();
    }

    private void onSessionLongClick(KilosSession session) {
        showSessionOptions(session);
    }

    private void setupFab() {
        findViewById(R.id.fab_add_session).setOnClickListener(v -> showNewSessionDialog());
    }

    private void showNewSessionDialog() {
        final EditText input = new EditText(this);
        input.setHint(getString(R.string.dialog_new_session_hint));
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT);

        new AlertDialog.Builder(this)
                .setTitle(R.string.dialog_new_session_title)
                .setView(input)
                .setPositiveButton(R.string.session_connect, (dialog, which) -> {
                    String sessionId = input.getText().toString().trim();
                    if (!TextUtils.isEmpty(sessionId)) {
                        createSession(sessionId);
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void createSession(String sessionId) {
        String groupId = currentGroupFilter != null ? currentGroupFilter : "default";
        String name = "Session " + (sessionId.length() > 8 ? sessionId.substring(sessionId.length() - 8) : sessionId);

        KilosSession session = new KilosSession(sessionId, groupId, name);
        storage.saveSession(session);
        loadData();

        Toast.makeText(this, "Session created: " + name, Toast.LENGTH_SHORT).show();
    }

    private void showSessionOptions(KilosSession session) {
        String[] options = {"Open (v0.3)", "Focus", "Disconnect", "Delete"};
        new AlertDialog.Builder(this)
                .setTitle(session.getDisplayName())
                .setItems(options, (dialog, which) -> {
                    switch (which) {
                        case 0: onSessionClick(session); break;
                        case 1: Toast.makeText(this, "Focus: " + session.getDisplayName(), Toast.LENGTH_SHORT).show(); break;
                        case 2: disconnectSession(session); break;
                        case 3: deleteSession(session); break;
                    }
                })
                .show();
    }

    private void disconnectSession(KilosSession session) {
        KilosSession updated = session.copyWithStatus(KilosSession.SessionStatus.DISCONNECTED);
        storage.saveSession(updated);
        loadData();
    }

    private void deleteSession(KilosSession session) {
        storage.deleteSession(session.getId());
        loadData();
    }

    private void showGroupOptions(SessionGroup group) {
        String[] options = {"Rename", "Change Color", "Delete Group"};
        new AlertDialog.Builder(this)
                .setTitle(group.getName())
                .setItems(options, (dialog, which) -> {
                    switch (which) {
                        case 0: renameGroup(group); break;
                        case 1: changeGroupColor(group); break;
                        case 2: deleteGroup(group); break;
                    }
                })
                .show();
    }

    private void renameGroup(SessionGroup group) {
        final EditText input = new EditText(this);
        input.setText(group.getName());
        new AlertDialog.Builder(this)
                .setTitle("Rename Group")
                .setView(input)
                .setPositiveButton(android.R.string.ok, (dialog, which) -> {
                    String newName = input.getText().toString().trim();
                    if (!TextUtils.isEmpty(newName)) {
                        SessionGroup updated = group.copyWithName(newName);
                        storage.saveGroup(updated);
                        loadData();
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void changeGroupColor(SessionGroup group) {
        int[] colors = {0xFF74B9FF, 0xFF00D4AA, 0xFFA29BFE, 0xFFFD79A8, 0xFFFF6B6B, 0xFFFDCB6E};
        String[] colorNames = {"Blue", "Teal", "Purple", "Pink", "Red", "Yellow"};

        new AlertDialog.Builder(this)
                .setTitle("Group Color")
                .setSingleChoiceItems(colorNames, 0, (dialog, which) -> {
                    SessionGroup updated = group.copyWithColor(colors[which]);
                    storage.saveGroup(updated);
                    loadData();
                    dialog.dismiss();
                })
                .show();
    }

    private void deleteGroup(SessionGroup group) {
        if ("default".equals(group.getId())) {
            Toast.makeText(this, "Cannot delete default group", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setMessage("Delete group '" + group.getName() + "'? Sessions will move to Default.")
                .setPositiveButton(android.R.string.ok, (dialog, which) -> {
                    storage.deleteGroup(group.getId());
                    loadData();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void showNewGroupDialog() {
        final EditText input = new EditText(this);
        input.setHint(getString(R.string.dialog_new_group_hint));
        new AlertDialog.Builder(this)
                .setTitle(R.string.dialog_new_group_title)
                .setView(input)
                .setPositiveButton(android.R.string.ok, (dialog, which) -> {
                    String name = input.getText().toString().trim();
                    if (!TextUtils.isEmpty(name)) {
                        SessionGroup group = new SessionGroup(name);
                        storage.saveGroup(group);
                        loadData();
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void checkOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Overlay permission needed for floating windows (v0.3)", Toast.LENGTH_LONG).show();
        }
    }

    private void requestOverlayPermission() {
        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:" + getPackageName()));
        startActivityForResult(intent, OVERLAY_PERMISSION_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_PERMISSION_REQUEST) {
            if (Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Overlay permission granted", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    // Adapters
    private static class GroupsAdapter extends BaseAdapter {
        private final java.util.function.Consumer<String> onClick;
        private final java.util.function.Consumer<SessionGroup> onLongClick;
        private final Set<String> expandedGroups;
        private List<SessionGroup> groups = new ArrayList<>();

        GroupsAdapter(java.util.function.Consumer<String> onClick,
                      java.util.function.Consumer<SessionGroup> onLongClick,
                      Set<String> expandedGroups) {
            this.onClick = onClick;
            this.onLongClick = onLongClick;
            this.expandedGroups = expandedGroups;
        }

        void submitList(List<SessionGroup> newGroups) {
            groups.clear();
            groups.addAll(newGroups);
            notifyDataSetChanged();
        }

        @Override
        public int getCount() {
            return groups.size();
        }

        @Override
        public SessionGroup getItem(int position) {
            return groups.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            SessionGroup group = getItem(position);
            boolean isExpanded = expandedGroups.contains(group.getId());

            if (convertView == null) {
                convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_group_chip, parent, false);
            }

            TextView tvName = convertView.findViewById(R.id.tv_group_name);
            View indicator = convertView.findViewById(R.id.group_indicator);

            tvName.setText(group.getName());
            tvName.setTextColor(group.getColor());
            indicator.setBackgroundColor(group.getColor());

            convertView.setOnClickListener(v -> onClick.accept(group.getId()));
            convertView.setOnLongClickListener(v -> { onLongClick.accept(group); return true; });

            return convertView;
        }
    }

    private static class SessionsAdapter extends BaseAdapter {
        private final java.util.function.Consumer<KilosSession> onClick;
        private final java.util.function.Consumer<KilosSession> onLongClick;
        private List<KilosSession> sessions = new ArrayList<>();

        SessionsAdapter(java.util.function.Consumer<KilosSession> onClick,
                        java.util.function.Consumer<KilosSession> onLongClick) {
            this.onClick = onClick;
            this.onLongClick = onLongClick;
        }

        void submitList(List<KilosSession> newSessions) {
            sessions.clear();
            sessions.addAll(newSessions);
            notifyDataSetChanged();
        }

        @Override
        public int getCount() {
            return sessions.size();
        }

        @Override
        public KilosSession getItem(int position) {
            return sessions.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            KilosSession session = getItem(position);

            if (convertView == null) {
                convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_session, parent, false);
            }

            TextView tvName = convertView.findViewById(R.id.tv_session_name);
            TextView tvSessionId = convertView.findViewById(R.id.tv_session_id);
            TextView tvGroup = convertView.findViewById(R.id.tv_group_name);
            TextView tvStatus = convertView.findViewById(R.id.tv_session_status);
            View statusIndicator = convertView.findViewById(R.id.status_indicator);
            Button btnOpen = convertView.findViewById(R.id.btn_open);

            tvName.setText(session.getDisplayName());
            String shortId = session.getSessionId();
            if (shortId.length() > 8) shortId = shortId.substring(0, 8);
            tvSessionId.setText("ses_" + shortId);
            tvGroup.setText(session.getGroupId());
            tvStatus.setText(session.getStatus().name());

            int statusColor;
            switch (session.getStatus()) {
                case CONNECTED:
                case HEARTBEAT_ACTIVE:
                    statusColor = 0xFF3FB950; break;
                case CONNECTING:
                case RECONNECTING:
                    statusColor = 0xFFD29922; break;
                case ERROR:
                case HEARTBEAT_FAILED:
                    statusColor = 0xFFF85149; break;
                default:
                    statusColor = 0xFF8B949E;
            }
            statusIndicator.setBackgroundColor(statusColor);

            btnOpen.setOnClickListener(v -> { if (onClick != null) onClick.accept(session); });

            convertView.setOnClickListener(v -> { if (onClick != null) onClick.accept(session); });
            convertView.setOnLongClickListener(v -> { if (onLongClick != null) onLongClick.accept(session); return true; });

            return convertView;
        }
    }
}