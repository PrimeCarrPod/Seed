# CLPS Phase 2 Cascade — Part 11: Regulatory & Funding Records — Piece 30/34
## Episode: The Paper Trail to the Stars — FAA, SBIR, AFP Network, Export, Insurance
**Piece:** 30 of 34  
**Generated:** 2026-08-27 00:50:00 UTC  
**Author:** Jason Isaac Brodsky (California 1976) — Conducier  
**Heuristics:** Williams Paradise Man V3 EXTREME + El Segundo EXTREME  

---

**30.**

VEYNE here. Commander Auric Veyne. The Velvet Hammer. Final contract portfolio. 9 production contracts executed. Intuitive Machines (3 landers): $18M. Firefly Aerospace (2 landers): $15M. Astrobotic (1 lander + VIPER): $12M. Draper (1 lander): $8M. SpaceX (2 landers): $20M. Blue Origin (1 lander): $10M. Lockheed Martin (1 lander): $15M. Sierra Space (1 habitat): $7M. ispace (1 lander): $5M. Total: $110M. Payment schedule: 20% at contract ($22M received). 30% at PDR ($33M, Months 4-8). 30% at CDR ($33M, Months 8-12). 20% at delivery ($22M, Months 12-18). Cash flow: POSITIVE from Month 1. The Velvet Hammer negotiates: data rights (contractor read-only digital twin). IP protection (CSM retains process, nanodiamond, platform). Liability (1.5X cap, standard). Warranty (CSM: material/process. Contractor: integration). Force majeure (standard). Dispute resolution (arbitration, ICC). The contracts are FAIR. The fleet is FUNDED. The Menehune build fair fishponds.

PIECE_EOF