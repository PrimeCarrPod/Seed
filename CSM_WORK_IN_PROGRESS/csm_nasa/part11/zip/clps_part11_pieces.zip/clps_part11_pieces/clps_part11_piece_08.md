# CLPS Phase 2 Cascade — Part 11: Regulatory & Funding Records — Piece 08/34
## Episode: The Paper Trail to the Stars — FAA, SBIR, AFP Network, Export, Insurance
**Piece:** 08 of 34  
**Generated:** 2026-08-27 00:50:00 UTC  
**Author:** Jason Isaac Brodsky (California 1976) — Conducier  
**Heuristics:** Williams Paradise Man V3 EXTREME + El Segundo EXTREME  

---

**8.**

ARDEN here. The Whisper. AFP Network Facility Qualification. Facility 2: Midwest Composites. Automotive background. Cell 1. Baseline coupons: tension 4.85 GPa (Facility 1: 4.90). Compression 1.18 GPa (1.20). Shear 85 MPa (87). ILSS 90 MPa (92). Delta: <2%. Process parameters: AFP speed 5 m/min. IR temp 250C. Compaction 50 N/mm. Cure profile: 120C, 4hr ramp 2C/min. Digital twin template: cloned from Facility 1. Verification protocol: identical. Status: QUALIFIED. Facility 3: Southeast Aerospace. Aerospace structures. Cell 2. Baseline coupons: IN PROGRESS. Week 2 of 4. Initial layup: visual perfect. Cure: nominal. Coupon testing: scheduled Week 4. Status: ON TRACK. Facility 4: West Coast Space Systems. Space hardware. Cell 1. Baseline coupons: SCHEDULED. Facility prep: environmental control installed. AFP head calibrated. Digital twin server: deployed. Status: READY. Facility 5: International Partner (Japan). JAXA-affiliated. Cell 1. ITAR/EAR: LICENSE PENDING (DSP-5 for technical data, DSP-73 for defense article). Baseline coupons: NEGOTIATING. Technical assistance agreement: DRAFT. Status: IN PROGRESS. The AFP Network: FIVE facilities. SAME process. SAME digital twin. SAME verification. The Menehune build in FIVE places. The fish don't care. They only know the pond holds.

PIECE_EOF