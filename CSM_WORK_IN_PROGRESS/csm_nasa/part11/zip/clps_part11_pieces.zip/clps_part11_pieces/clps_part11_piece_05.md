# CLPS Phase 2 Cascade — Part 11: Regulatory & Funding Records — Piece 05/34
## Episode: The Paper Trail to the Stars — FAA, SBIR, AFP Network, Export, Insurance
**Piece:** 05 of 34  
**Generated:** 2026-08-27 00:50:00 UTC  
**Author:** Jason Isaac Brodsky (California 1976) — Conducier  
**Heuristics:** Williams Paradise Man V3 EXTREME + El Segundo EXTREME  

---

**5.**

ZIRCONIA here. Director of Operations. Accountant Insurance Heuristic. Seventeen directorates active. The regulatory and funding money. FAA AST Consultation: forty-seven thousand dollars (consultant fees, travel, prep, legal). SBIR Phase II Proposal: twenty-three thousand (proposal prep, cost volume, technical volume, CVs). AFP Network Qualification (Facilities 2-5): four hundred thousand (baseline coupons, process verification, digital twin setup, audit travel). Export Licenses (ITAR/EAR for Facilities 5, international TIMs): sixty-seven thousand (legal, classification, license applications, compliance). Insurance Binders (production policy, product liability, D&O): one hundred twenty thousand (first year premium, three major insurers). Production Contract Legal: eighty-nine thousand (contract negotiation, IP terms, liability allocation, data rights). Total Regulatory/Funding Campaign: seven hundred forty-six thousand dollars. The FUNDING INCOMING: SBIR Phase II Award: one point five million (twenty-four months). NASA Tipping Point (target): twelve million (thirty-six months). NASA Game Changing Development (target): twenty million (forty-eight months). Production Contracts (three LOIs): forty-five million (nine months). Total Projected Inflow: seventy-eight point five million. ROI: ten thousand five hundred percent. The Zirconia number: seven hundred forty-six thousand investment. Seventy-eight point five million projected. The night shift doesn't do bad math. The Menehune build profitable fishponds.

PIECE_EOF