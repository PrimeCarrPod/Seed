# CLPS Phase 2 Cascade — Part 11: Regulatory & Funding Records — Piece 26/34
## Episode: The Paper Trail to the Stars — FAA, SBIR, AFP Network, Export, Insurance
**Piece:** 26 of 34  
**Generated:** 2026-08-27 00:50:00 UTC  
**Author:** Jason Isaac Brodsky (California 1976) — Conducier  
**Heuristics:** Williams Paradise Man V3 EXTREME + El Segundo EXTREME  

---

**26.**

CROSS here. The Wrench Whisperer. Production contract integration elimination. Intuitive Machines: 12 legs + 3 adapters. Fabrication: Facility 1. Integration: ZERO (legs arrive as legs, adapters as adapters). Bolts: 36 per lander set. Hours: 4 per lander set. Firefly: 4 vessels (16 quarters) + 2 adapters. Fabrication: Facility 2. Integration: ZERO. Bolts: 48 per lander set (vessel flanges). Hours: 2 per lander set. Astrobotic: 4 legs + 1 adapter. Fabrication: Facility 1 (legs), Facility 3 (adapter). Integration: ZERO. Bolts: 36 + 36 per lander set. Hours: 4 + 2 per lander set. Draper: 4 legs + 1 vessel + 1 adapter. Fabrication: Facility 4. Integration: ZERO. SpaceX: 4 vessels (16 quarters). Fabrication: Facility 2. Integration: ZERO. Blue Origin: 2 adapters. Fabrication: Facility 3. Integration: ZERO. Lockheed: 4 legs + 2 vessels + 2 adapters. Fabrication: Facility 4. Integration: ZERO. Sierra: 4 adapters (habitat). Fabrication: Facility 3. Integration: ZERO. ispace: 4 legs + 2 vessels + 2 adapters. Fabrication: Facility 5. Integration: ZERO. THE INTEGRATION IS ELIMINATED. THE WRENCH IS RETIRED. THE FLEET ARRIVES AS A FLEET. YOU STACK. YOU BOLT. YOU FLY.

PIECE_EOF