# CLPS Phase 2 Cascade — Part 11: Regulatory & Funding Records — Piece 13/34
## Episode: The Paper Trail to the Stars — FAA, SBIR, AFP Network, Export, Insurance
**Piece:** 13 of 34  
**Generated:** 2026-08-27 00:50:00 UTC  
**Author:** Jason Isaac Brodsky (California 1976) — Conducier  
**Heuristics:** Williams Paradise Man V3 EXTREME + El Segundo EXTREME  

---

**13.**

DORNE here. The Lie Detector. Regulatory assumptions stress test. Assumption 1: "FAA will accept thermoplastic for primary structure." Test: FAA consultation complete. Trish Kowalski: "We can work with this." Certification basis questionnaire issued. Response drafted. Status: SUPPORTED. Assumption 2: "SBIR Phase II will be awarded." Test: Phase I final report includes EXECUTED test campaign. Contractor LOIs ($45M). Digital twin correlation (0.998). TRL 6 demonstrated. Status: HIGH CONFIDENCE. Assumption 3: "AFP Network facilities will qualify." Test: Facility 2 qualified (<2% delta). Facility 3 on track. Facility 4 ready. Facility 5 negotiating. Process spec frozen. Digital twin template cloned. Status: ON TRACK. Assumption 4: "Export licenses for Facility 5 will be granted." Test: DSP-5 for technical data (standard for allied nation). DSP-73 for defense article (standard for space cooperation). JAXA partnership documented. Artemis Accords signatory. Status: STANDARD PROCESS. Assumption 5: "Insurance will cover production." Test: Three major insurers bound. Premium 40-60% reduction. "Novel materials" exclusion removed. Status: CLOSED. Assumption 6: "Contractors will convert LOIs to contracts." Test: LOIs signed. PDR/CDR schedules agreed. Payment terms negotiated. Data rights agreed. Status: IN PROGRESS. The Lie Detector reads: ALL ASSUMPTIONS SUPPORTED OR ON TRACK. The path is CLEAR.

PIECE_EOF