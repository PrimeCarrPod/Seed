
PIECE_EOF# CLPS Phase 2 Cascade — Part 11: Regulatory & Funding Records — Piece 14/34
## Episode: The Paper Trail to the Stars — FAA, SBIR, AFP Network, Export, Insurance
**Piece:** 14 of 34  
**Generated:** 2026-08-27 00:50:00 UTC  
**Author:** Jason Isaac Brodsky (California 1976) — Conducier  
**Heuristics:** Williams Paradise Man V3 EXTREME + El Segundo EXTREME  

---

**14.**

FEN here. The Navigator. Regulatory timeline. Month 1-3: FAA consultation (DONE). SBIR Phase II submitted (DONE). AFP Facility 2 qualified (DONE). Facility 3 baseline (IN PROGRESS). Export license applications (SUBMITTED). Insurance binders (BOUND). Month 4-6: FAA certification basis questionnaire response. SBIR Phase II award decision. Facility 3 qualified. Facility 4 baseline. Facility 5 license progress. TIM-004 through 006 (Draper, SpaceX, Blue Origin). Month 7-9: FAA means of compliance. SBIR Phase II kickoff. Facility 4 qualified. Facility 5 license granted. TIM-007 through 009 (Lockheed, Sierra, ispace). LOI → Contract conversion (3). First article inspections. Month 10-18: FAA type certification basis. SBIR Phase II flight articles. Full qual testing. Production contracts execution. AFP Network full rate. Tipping Point proposal. Game Changing proposal. The navigation is SET. The critical path: FAA certification basis → Type certificate → Production authorization. The Moon is WAITING. The course is PLOTTED.
