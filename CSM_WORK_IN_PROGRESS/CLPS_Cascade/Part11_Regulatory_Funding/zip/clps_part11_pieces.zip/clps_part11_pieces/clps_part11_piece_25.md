
PIECE_EOF# CLPS Phase 2 Cascade — Part 11: Regulatory & Funding Records — Piece 25/34
## Episode: The Paper Trail to the Stars — FAA, SBIR, AFP Network, Export, Insurance
**Piece:** 25 of 34  
**Generated:** 2026-08-27 00:50:00 UTC  
**Author:** Jason Isaac Brodsky (California 1976) — Conducier  
**Heuristics:** Williams Paradise Man V3 EXTREME + El Segundo EXTREME  

---

**25.**

ARDEN here. The Whisper. AFP Network production readiness. Facility 1: QUALIFIED. Rate: 3 lander sets/shift. Facility 2: QUALIFIED. Rate: 3 lander sets/shift. Facility 3: ON TRACK (Week 4 coupon test). Rate: 2 lander sets/shift. Facility 4: READY (baseline scheduled). Rate: 2 lander sets/shift. Facility 5: NEGOTIATING (license pending). Rate: 1 lander set/shift (initial). Total capacity: 11 lander sets/shift × 3 shifts = 33/day. 750/year. CLPS manifest: 9 landers (current). We have 83X capacity margin. The Menehune build capacity in FIVE places. The fish don't care. They only know the pond holds.
