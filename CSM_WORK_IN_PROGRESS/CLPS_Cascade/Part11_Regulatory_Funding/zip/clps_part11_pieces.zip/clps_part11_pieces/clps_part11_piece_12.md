
PIECE_EOF# CLPS Phase 2 Cascade — Part 11: Regulatory & Funding Records — Piece 12/34
## Episode: The Paper Trail to the Stars — FAA, SBIR, AFP Network, Export, Insurance
**Piece:** 12 of 34  
**Generated:** 2026-08-27 00:50:00 UTC  
**Author:** Jason Isaac Brodsky (California 1976) — Conducier  
**Heuristics:** Williams Paradise Man V3 EXTREME + El Segundo EXTREME  

---

**12.**

VEYNE again. Production contracts. Three LOIs → Contracts. Intuitive Machines: Leg sets (4 legs × 3 landers = 12 legs) + Adapters (3). Value: $18M. Schedule: PDR Q1, CDR Q2, First article Q3, Production Q4. Firefly: Vessel sets (2 tanks × 2 landers = 4 vessels = 16 quarters) + Adapters (2). Value: $15M. Schedule: Scaling study Q1, PDR Q2, First article Q3, Production Q4. Astrobotic: Leg sets (4 legs × 1 lander = 4 legs) + Adapters (1 for VIPER). Value: $12M. Schedule: CDR integration Q1, First article Q2, Production Q3. Contract terms: Firm-fixed-price (contractor preference). CSM warrants: material properties, process conformance, digital twin accuracy. Contractor warrants: integration design, interface loads, mission assurance. Liability cap: 1.5X contract value (industry standard). Data rights: Contractor gets read-only digital twin for their articles. CSM retains: process IP, nanodiamond synthesis, digital twin platform. Payment: 20% at contract, 30% at PDR, 30% at CDR, 20% at delivery. The Velvet Hammer signs. The contracts are FAIR. The Menehune build fair fishponds.
