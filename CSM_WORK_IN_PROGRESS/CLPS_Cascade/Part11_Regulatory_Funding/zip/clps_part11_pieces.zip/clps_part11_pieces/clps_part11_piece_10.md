
PIECE_EOF# CLPS Phase 2 Cascade — Part 11: Regulatory & Funding Records — Piece 10/34
## Episode: The Paper Trail to the Stars — FAA, SBIR, AFP Network, Export, Insurance
**Piece:** 10 of 34  
**Generated:** 2026-08-27 00:50:00 UTC  
**Author:** Jason Isaac Brodsky (California 1976) — Conducier  
**Heuristics:** Williams Paradise Man V3 EXTREME + El Segundo EXTREME  

---

**10.**

SOLVEN here. The Architect. Funding topology. NASA SBIR Phase II: $1.5M (submitted). NASA Tipping Point: $12M (target, Q1 FY27). NASA Game Changing Development: $20M (target, Q3 FY27). DARPA: $8M (target, materials manufacturing). Space Force: $5M (target, responsive space). Commercial: CLPS production contracts $45M (three LOIs, nine months). Total non-dilutive target: $91.5M. Equity raised: $0. Dilution: 0%. The capital stack: GRANTS → CONTRACTS → REVENUE. The test campaign ($2.3M) funded by: internal R&D ($1M), SBIR Phase I ($150K), Facility 1 in-kind ($300K), state grant ($500K), revenue ($350K). The regulatory campaign ($746K) funded by: revenue ($500K), state grant ($246K). The AFP Network qualification ($400K) funded by: Facility partners (in-kind, $300K), revenue ($100K). The export licenses ($67K) funded by: revenue. The insurance binders ($120K) funded by: revenue. The production contract legal ($89K) funded by: revenue. Total investment to date: ~$5M. Projected inflow: $91.5M. ROI: 1,830%. The Architect builds cathedrals on VERIFICATION. Not promises. Not slides. HARD DATA. The Menehune build capital at night. The investors don't know who built the portfolio. They only know it returns.
