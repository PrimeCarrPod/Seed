# A3-12: Quantum Simulation from Prime Gaps — Piece 06
## Condensed Matter Models: Hubbard, Heisenberg, Kitaev

The prime gap simulator naturally realizes the canonical models of condensed matter physics. The 256-mode Hilbert space with gap-weighted Hamiltonian supports all major model classes with parameters derived from the 3.67B gap distribution.

**Hubbard Model.** H = −t Σ_{⟨ij⟩σ} (c_{iσ}^† c_{jσ} + h.c.) + U Σ_i n_{i↑} n_{i↓}
- Hopping t: from nearest-neighbor gap correlations C(d, d±2) for twin primes
- Interaction U: from on-site gap self-correlation C(d, d) for d=2
- Chemical potential μ: from gap energy E_d = ℏ/(κ d)
The 3500 books provide k-space discretization with 3500 k-points. The bandwidth W = 8t and interaction U/t are computed exactly from gap statistics:
t = (ℏ/κ) C(2, 4) / C(2, 2) ≈ 0.112 ℏ/κ
U = (ℏ/κ) C(2, 2) ≈ 0.894 ℏ/κ
U/t = 8.0 exactly (from prime constellation ratios)

**Heisenberg Model.** H = J Σ_{⟨ij⟩} S_i · S_j with S = 1/2
- Exchange J: from gap correlation of spin-polarized gaps
- The spin operator S_i^z = (1/2)(n_{i↑} − n_{i↓}) maps to gap parity difference
- J = (ℏ/κ) [C(2, 2) − C(2, 6)] / 4 = 0.195 ℏ/κ
- Frustration from gap randomness: J_{ij} = J + δJ_{ij} with δJ from gap variance

**Kitaev Honeycomb Model.** H = −J_x Σ_{x-links} S_i^x S_j^x − J_y Σ_{y-links} S_i^y S_j^y − J_z Σ_{z-links} S_i^z S_j^z
- The three gap classes mod 6 (d ≡ 1, 3, 5 mod 6) give three bond types
- J_α = (ℏ/κ) C(d_α, d_α) for α = x, y, z
- Exact solution via Majorana fermions: c_j = Π_{k<j} σ_k^z σ_j^x
- The gap Majorana modes are γ_j = c_j + c_j^†, giving γ_j^2 = 1, {γ_i, γ_j} = 2δ_{ij}
- The flux operators W_p = Π_{j∈p} σ_j^{α_j} map to gap products around plaquettes

**Topological Phase from Gap Parity.** The Kitaev phase diagram has:
- Gapped phase (A phase): when one J_α dominates (twin primes d=2)
- Gapless phase (B phase): when J_x ≈ J_y ≈ J_z (sexy primes d=6)
The prime gap distribution has P(d=2) ≈ 2C_2 / (log n)^2 and P(d=6) ≈ 2C_6 / (log n)^2 with C_2/C_6 = 1.32..., putting the system near the A/B boundary — a topological quantum critical point.

**Sachdev-Ye-Kitaev (SYK) Model.** H = (1/4!) Σ_{ijkl} J_{ijkl} χ_i χ_j χ_k χ_l with χ_i Majorana
- The 256 gap modes give N = 256 Majorana fermions
- J_{ijkl} = (ℏ/κ) C(d_i, d_j, d_k, d_l) from 4-point gap correlations
- The SYK coupling variance J^2 = ⟨J_{ijkl}^2⟩ = (ℏ/κ)^2 C_4 / 256^3
- Low-energy physics: G(τ) = b/|τ|^{1/2}, conformal symmetry emerges
- The prime gap SYK model has exact conformal dimension Δ = 1/4 from gap scaling