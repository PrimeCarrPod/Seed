# A3-12: Quantum Simulation from Prime Gaps — Piece 11
## Experimental Implementation Roadmap

The prime gap quantum simulator is implementable on near-term quantum hardware. The 256-mode Hilbert space maps naturally to photonic orbital angular momentum (OAM), superconducting transmons, trapped ions, and neutral atom arrays.

**Photonic OAM Implementation (Primary).**
- 256 OAM modes: ℓ = −128 to +127 (or ℓ = 0 to 255)
- PG-QFT: 17-layer multi-plane light conversion (MPLC) with 256×256 unitary
- Gap state preparation: |Ψ⟩ = Σ_d √P(d) |ℓ=d⟩ via SLM + Fourier optics
- Time evolution: phase modulation φ_d(t) = t/(κ d) on each mode
- Measurement: single-photon detection + mode sorting (log₂ 256 = 8 bits)
- Resources: 1 laser, 1 SLM, 1 MPLC, 1 SNSPD array
- Rate: 10^6 photons/sec → 10^6 samples/sec
- Verification: Bell violation S = 2.3724 (A3-09), syndrome extraction (A3-11)

**Superconducting Transmon Implementation.**
- 256 transmons in 2D array (16×16)
- Frequency allocation: ω_d = ω_0 / d for d = 1..256
- Coupling: capacitive g_{dd'} = g_0 C(d, d') from gap correlations
- PG-QFT: fast flux pulses implementing F_{256} in 256 ns
- Error correction: C_2 = [[256,1,3]] code from twin primes (A3-11)
- T1 > 100 μs, T2 > 50 μs, gate fidelity > 99.9%
- Simulation time: 10 μs per Trotter step × 3500 = 35 ms

**Trapped Ion Implementation.**
- 256 ions in linear Paul trap (or 2D array)
- Modes: radial phonons with frequencies ω_d = ω_0 √d
- Gap state: |Ψ⟩ = Σ_d √P(d) |n_d=1⟩ (one phonon per mode)
- PG-QFT: Mølmer-Sørensen gates implementing F_{256}
- Individual addressing: 256 laser beams or AOD
- Heating rate < 1 quanta/sec, coherence > 1 sec
- Native long-range interactions match gap correlations

**Neutral Atom Array (Rydberg).**
- 256 atoms in 16×16 optical tweezers
- Rydberg states |r_d⟩ with principal quantum number n_d = n_0 + d
- Gap Hamiltonian: H = Σ_d (ℏ/κ d) |r_d⟩⟨r_d| + Σ_{d≠d'} V_{dd'} |r_d r_{d'}⟩⟨r_d r_{d'}|
- Blockade radius R_b maps to gap correlation length ξ = 150
- PG-QFT: global Rydberg pulses + local addressing
- Coherence > 10 sec, gate fidelity > 99.5%

**Classical Precomputation.** The 3.67B gaps from PrimeBookOne are precomputed:
- Gap sequence {d_n} stored as 4-byte integers: 14.7 GB
- Correlation matrix C_{dd'}: 256×256 = 65K entries, 0.5 MB
- PG-QFT matrix F_{256}: 256×256 complex, 1 MB
- All fits in GPU memory (24 GB H100)
- Real-time simulation: GPU computes U(t)|ψ⟩ in < 1 ms per step

**Verification Protocol.**
1. Prepare |Ψ⟩ = Σ_d √P(d) |d⟩
2. Apply PG-QFT, measure in computational basis → verify P(d)
3. Apply time evolution U(t), measure energy distribution → verify E_n = ℏ/(κ d_n)
4. Extract syndrome via V_{PG} + 8-qubit measure → verify QECC (A3-11)
5. Measure Bell violation on logical qubit → verify S = 2.3724
6. Simulate target Hamiltonian → compare with classical exact diagonalization