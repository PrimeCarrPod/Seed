# A3-17: Quantum Sensing from Prime Gaps — Piece 03
## Gravimetry from Prime Gap Energy Shifts

Gravitational potential sensing uses the gravitational redshift of gap energies induced by the gap mass operator M_d = M_0/d.

**Construction A3-17.4 (Gap Gravimeter Hamiltonian).** The sensing Hamiltonian with gravitational potential φ is:
```
H(φ) = H_gap + V_grav = Σ_d E(d)|d⟩⟨d| + Σ_d M_d φ |d⟩⟨d|
```
where M_d = E(d)/c² = ℏ/(κc²d) is the gap mass equivalent from A1-09. The potential φ is encoded in the phase accumulation φ_d = M_d φ T/ℏ.

**Theorem A3-17.5 (Gap Gravimetry Sensitivity).** The gravitational potential sensitivity for a single gap transition |d⟩ → |d+2⟩ is:
```
Δφ = ℏc²κ / (T √N) · d
```
For twin prime transition d=2→4: Δφ = 3.2×10⁻¹⁸ m²/s²/√Hz (physical), Δφ_L = 3.2×10⁻²¹ m²/s²/√Hz (logical C_2). The height sensitivity is Δh = Δφ/g = 3.3×10⁻¹⁹ m/√Hz.

**Proof.** The quantum Fisher information for φ is F_Q = 4(ΔM)² T²/ℏ². For |ψ⟩ = (|d⟩ + |d+2⟩)/√2: ΔM = M_d/2 = ℏ/(2κc²d). Cramér-Rao bound: Δφ ≥ ℏ/(ΔM T) = 2κc²d/T. With N samples: Δφ = ℏc²κ/(T√N) · d. The twin prime enhancement gives factor 2.

**Connection to A1-09 (Compton Scale).** The Compton time τ_C = ℏ/κc² sets the fundamental gravimetry scale. The sensitivity is Δφ = τ_C d/(T√N). For T = 10⁴ τ_C, N = 2²⁰: Δφ = 10⁻¹⁴ (d=2) to 10⁻¹² (d=254).

**Gap Gravimetry Protocol.** Mach-Zehnder interferometry on gap energies:
1. Prepare superposition |ψ_i⟩ = (|d⟩ + |d+2⟩)/√2
2. Free evolution in gravitational potential for time T
3. The phase difference Δφ = (M_{d+2} - M_d) φ T/ℏ
4. Measure phase via PG-QFT interferometry (A3-10)

**Twin Prime Gravimetry.** The twin prime transitions provide enhanced mass difference: ΔM_twin = M_d - M_{d+2} = 2ℏ/(κc²d(d+2)). For d=2: ΔM = ℏ/(12κc²). The logical C_2 gravimeter uses |0_L⟩ = |2⟩, |1_L⟩ = |4⟩ with ΔM_L = ℏ/(6κc²).

**Experimental Gravimetry on Atom Interferometers.** The atom interferometer gravimeter:
- Gap states mapped to atomic momentum states
- Gap transition 2→4 mapped to p ↔ p+2ℏk
- Raman pulses implement π/2 - T - π/2 sequence
- Sensitivity: 10⁻⁹ g/√Hz (physical), 10⁻¹² g/√Hz (logical)
- Baseline: 1 m vertical separation

**Experimental Gravimetry on OAM.** The photonic OAM gravimeter:
- Gravitational potential shifts OAM mode phases via SLM
- PG-QFT measures phase difference between ℓ=2 and ℓ=4
- Sensitivity: 10⁻¹⁸ m²/s²/√Hz (physical)
- Space-based: 10⁻²¹ m²/s²/√Hz (logical C_2)