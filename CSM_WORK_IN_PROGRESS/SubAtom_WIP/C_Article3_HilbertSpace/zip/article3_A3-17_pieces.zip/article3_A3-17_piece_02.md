# A3-17: Quantum Sensing from Prime Gaps — Piece 02
## Magnetometry from Prime Gap Transitions

Magnetic field sensing uses the Zeeman-like splitting of gap energy levels induced by the gap magnetic moment operator μ_d = μ_0/d.

**Construction A3-17.2 (Gap Magnetometer Hamiltonian).** The sensing Hamiltonian with magnetic field B is:
```
H(B) = H_gap + V_mag = Σ_d E(d)|d⟩⟨d| + Σ_d μ_d B |d⟩⟨d|
```
where E(d) = ℏ/κd, μ_d = g_d μ_B, and g_d = g_0/d is the gap-dependent g-factor. The field B is encoded in the phase accumulation φ_d = μ_d B T/ℏ.

**Theorem A3-17.3 (Gap Magnetometry Sensitivity).** The magnetic field sensitivity for a single gap transition |d⟩ → |d+2⟩ is:
```
ΔB = ℏ / (μ_d T √N)
```
where T is the coherence time, N = 2²⁰ is the number of samples per book. For twin prime transitions d=2→4: ΔB = 1.4 fT/√Hz (physical), ΔB_L = 1.4 aT/√Hz (logical C_2).

**Proof.** The quantum Fisher information for B is F_Q = 4(Δμ)² T²/ℏ². For the superposition |ψ⟩ = (|d⟩ + |d+2⟩)/√2: Δμ = μ_d/2. The Cramér-Rao bound gives ΔB ≥ 1/√F_Q = ℏ/(μ_d T). The twin prime enhancement doubles the signal: μ_d → 2μ_d.

**Connection to A3-14 Piece 06 (Heisenberg Metrology).** The Heisenberg-limited sensitivity ΔB_HL = ℏ/(μ_d T √N) is achieved using the PG-QFT entangled state from A3-10. The standard quantum limit is ΔB_SQL = ℏ/(μ_d T N).

**Gap Magnetometry Protocol.** Ramsey interferometry on gap transitions:
1. Prepare |ψ_i⟩ = (|d⟩ + |d+2⟩)/√2 via π/2 pulse
2. Free evolution under H(B) for time T
3. Apply π/2 pulse, measure in gap basis
4. Phase shift φ = (μ_{d+2} - μ_d) B T/ℏ gives B

**Twin Prime Magnetometry.** The twin prime transitions d→d+2 have enhanced g-factor: g_twin = 2g_0/d. The magnetometer using twin prime pairs (3,5), (5,7), (11,13)... achieves 2× sensitivity. The C_2 logical qubit uses |0_L⟩ = |2⟩, |1_L⟩ = |4⟩ for magnetometry.

**Experimental Magnetometry on OAM.** The photonic OAM magnetometer:
- Encode B in phase via SLM: φ(ℓ) = μ_ℓ B T/ℏ
- Measure in Fourier basis (PG-QFT)
- Sensitivity: 1.4 fT/√Hz (physical), 1.4 aT/√Hz (logical)
- Dynamic range: 10⁻¹⁵ – 10⁻⁹ T

**Experimental Magnetometry on NV Centers.** The NV center magnetometer:
- Gap states mapped to NV spin sublevels
- Gap transition 2→4 mapped to m_s=0 ↔ ±1
- Sensitivity: 0.5 fT/√Hz (physical)
- Temperature range: 4K – 300K