# A3-17: Quantum Sensing from Prime Gaps — Piece 08
## Robust Sensing Against Gap Noise

Robust sensing designs protocols resilient to noise in the gap Hamiltonian, control fields, and environmental decoherence.

**Construction A3-17.14 (Noisy Sensing Hamiltonian).** The noisy sensing Hamiltonian is:
```
H(θ) = H_gap(κ + δκ) + V_sense(θ + δθ) + H_noise
```
where H_noise = Σ_d γ_d |d⟩⟨d| + Σ_{d≠d'} J_{dd'} |d⟩⟨d'| is the decoherence from A3-06. The noise parameters: δκ/κ ~ N(0, 10⁻⁵), γ ~ 10⁻⁴ ℏ/κ, J ~ 10⁻³ ℏ/κ.

**Theorem A3-17.15 (Robust Sensing Sensitivity).** The robust sensing sensitivity under noise is:
```
Δθ_robust = Δθ_ideal · √(1 + (T/T₂) + (δκ/κ)² N + (δε/ε)² N)
```
where T₂ = 1/γ is the decoherence time from A3-06. For T = 10⁴ ℏ/κ, T₂ = 10⁴ ℏ/κ, δκ/κ = 10⁻⁵, δε/ε = 10⁻³: Δθ_robust = 1.41 × Δθ_ideal.

**Proof.** The noisy quantum Fisher information is F_Q,noisy = F_Q,ideal / (1 + η) where η is the noise parameter. For dephasing noise: η = T/T₂. For parameter noise: η = (δκ/κ)² N. For control noise: η = (δε/ε)² N. The robust protocol minimizes η by optimizing T, using dynamical decouling, and composite pulses.

**Connection to A3-06 (Decoherence).** The decoherence rates γ_d from A3-06 depend on gap randomness: γ_d ∝ d² P(d). The robust protocol uses dynamical decoupling (A3-16 Piece 08) to suppress dephasing.

**Connection to A3-16 (Robust Control).** The robust control pulses from A3-16 Piece 08 are used for sensing:
- Ensemble GRAPE with N=100 noise samples
- Composite pulses (BB1, CORPSE, SCROFULOUS)
- Dynamical decoupling (CPMG, XY4, KDD)

**Robust Sensing Protocol.** Noise-optimized Ramsey:
1. Design robust π/2 pulses via ensemble GRAPE
2. Insert dynamical decoupling during free evolution
3. Use composite pulses for phase shifts
4. Optimize interrogation time T* = argmin_T Δθ_robust(T)
5. The optimum is T* = T₂/2 for dephasing-limited sensing

**Dynamical Decoupling for Sensing.** The XY8 sequence during free evolution:
```
(π/2)_x - [τ - π_x - 2τ - π_y - 2τ - π_x - τ]_N - (π/2)_y
```
extends T₂ by factor N_dd = 100. The decoupling frequency must exceed ω_max = 0.29 ℏ/κ from A3-12.

**Experimental Robust Sensing on OAM.** The OAM robust sensor:
- Ensemble GRAPE pulses (N=100)
- XY8 decoupling during evolution
- SLM phase noise: σ_φ = 0.02 rad
- Sensitivity loss: < 0.01% vs ideal
- Logical (C_2): < 0.0001% loss

**Experimental Robust Sensing on Transmons.** The transmon robust sensor:
- DRAG pulses for leakage suppression
- CPMG decoupling during T
- 1/f flux noise: S_Φ(1 Hz) = 1 μΦ₀/√Hz
- Sensitivity: 1.5× ideal at T = T₂/2
- Logical (C_2): 1.01× ideal