# A3-17: Quantum Sensing from Prime Gaps — Piece 09
## Multi-Parameter Estimation from Prime Gaps

The gap Hamiltonian simultaneously encodes multiple physical parameters (B, φ, ω, T, κ), enabling multi-parameter quantum estimation with the quantum Fisher information matrix.

**Construction A3-17.16 (Multi-Parameter Gap Hamiltonian).** The multi-parameter Hamiltonian is:
```
H(θ) = Σ_d [ E(d) + μ_d B + M_d φ + ℏ ω d + ... ] |d⟩⟨d|
```
where θ = (B, φ, ω, T, κ) is the parameter vector. The sensing operators are:
- μ_d = μ_0/d for magnetometry
- M_d = ℏ/(κc²d) for gravimetry
- ℏω d for frequency metrology
- ℏκ d for temperature
- ℏ/d for κ metrology

**Theorem A3-17.17 (Gap Multi-Parameter Cramér-Rao Bound).** The covariance matrix of any unbiased estimator satisfies:
```
Cov(θ̂) ≥ F_Q(θ)⁻¹
```
where the quantum Fisher information matrix is:
```
[F_Q]_{ij} = 4 Re[ ⟨∂_i ψ|∂_j ψ⟩ - ⟨∂_i ψ|ψ⟩⟨ψ|∂_j ψ⟩ ]
```
For the gap system, the optimal measurement is the PG-QFT basis (A3-10).

**Proof.** The quantum Fisher information matrix for commuting parameters (all diagonal in gap basis) is diagonal:
```
[F_Q]_{BB} = 4 T² Σ_d (μ_d/2)² = T² Σ_d μ_0²/d²
[F_Q]_{φφ} = 4 T² Σ_d (M_d/2)² = T² Σ_d ℏ²/(κ²c⁴d²)
[F_Q]_{ωω} = 4 T² Σ_d (ℏ d/2)² = ℏ² T² Σ_d d²
```
The cross-terms vanish for commuting Hamiltonians. The optimal measurement is the common eigenbasis (gap basis).

**Connection to A3-14 (Metrology).** The multi-parameter Fisher information from A3-14 determines the optimal resource allocation. The QML agent (A3-13) learns the optimal trade-off between parameters.

**Trade-off Relations.** The Heisenberg limit for multi-parameter estimation:
```
Σ_i w_i Δθ_i² ≥ Tr[W F_Q⁻¹]
```
where W is the weight matrix. For equal weights: Σ_i Δθ_i² ≥ Tr[F_Q⁻¹]. The gap statistics determine the trade-off: magnetometry (d⁻²) vs frequency (d²) are anti-correlated.

**Optimal Probe State for Multi-Parameter.** The optimal state maximizes det(F_Q) or minimizes Tr(F_Q⁻¹):
```
|ψ_opt⟩ = Σ_d c_d |d⟩,  c_d = argmax det(F_Q(c))
```
For gap sensing: c_d ∝ 1/d (magnetometry) or c_d ∝ d (frequency). The QML agent learns the optimal c_d.

**Experimental Multi-Parameter Sensing on OAM.** The OAM multi-parameter sensor:
- Simultaneously measures B, φ, ω
- Fourier basis measurement extracts all phases
- QML agent optimizes SLM phase for each parameter
- Sensitivity: ΔB = 0.5 fT/√Hz, Δφ = 10⁻¹⁸ m²/s²/√Hz, Δω/ω = 10⁻¹⁸
- Cross-talk: < 1% between parameters

**Experimental Multi-Parameter Sensing on NV Centers.** The NV multi-parameter sensor:
- Electron spin measures B (Zeeman) and T (strain)
- Nuclear spin measures φ (gravitational) and ω (frequency)
- Decoupled measurements via dynamical decoupling
- Sensitivity: ΔB = 0.1 fT/√Hz, ΔT = 1 mK/√Hz