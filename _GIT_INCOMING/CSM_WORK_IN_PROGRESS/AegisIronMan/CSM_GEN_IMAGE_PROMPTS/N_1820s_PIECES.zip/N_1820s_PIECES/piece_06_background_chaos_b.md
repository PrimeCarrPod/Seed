### III. BACKGROUND CHAOS — CONTINUED (INFRASTRUCTURE, BUILDINGS, LONSDALEITE, TOXIC GEOMETRY, ERA-TEXT)

**Infrastructure as Information Carrier — Detailed:**
- **Vitriol Chamber Row:** Lead chambers (12× in series, 90% H₂SO₄), Glover tower (nitrogen oxides recovery), Gay-Lussac tower (absorption), **chemistry as vertical flow** — SO₂ + NO + H₂O → H₂SO₄, heat = exothermic, **Charles's generator** taps vitriol at 90% concentration.
- **Iron Filings Hopper:** Volumetric feeder (500 kg capacity, 500 kg/hr max), vibratory discharge (0.5 Hz), dust collector (cyclone, 99% capture), **filings purity** = 99.5% Fe (0.5% C, Si, Mn), **stoichiometric precision** = 1 mol Fe per mol H₂.
- **Gasometer Battery:** Three telescopic bells (50,000 ft³ each, hydrogen dedicated), water seal (25 mm H₂O constant pressure), **level indicator** = float + counterweight + pointer, **hydrogen bell** = painted hydrogen blue, **coal gas bells** = painted stone grey.
- **Semaphore Telegraph:** Chappe system (Paris-Lille, 230 km, 15 stations), **aerial observation** = Gay-Lussac at 7,016 m sees Station 12 (20 km), **signal code** = 98 symbols (2 arms × 7 positions each), **transmission rate** = 2 symbols/min, **aerial message** = "ALT 7016 M DIP 72 TEMP -20".
- **Instrument Maker's Workshop:** Barometer (Fortin, mercury, temperature-compensated cistern), Thermometer (Réaumur/mercury, 0.1°), Magnetometer (Borda dip circle, agate bearing), Hygrometer (Saussure, human hair), **all calibrated** at Académie / Royal Society, **certification stamps** on each.

**Buildings as Data Structures (1820s Specific) — Detailed:**
- **Tuileries Generator Shed (Charles's Laboratory):** 
  - Window grid = reaction progress array (lit = feeding, dark = idle, 0.5 Hz pulse)
  - Structural columns = load paths = reactor weight (500 kg Fe + 2,500 L vitriol)
  - HVAC ducts = fume extraction = vitriol vapor + H₂S scrubber
  - Rooftop equipment = gas outlet stack (copper, 50 mm, 10 m tall) = RF antenna for protonic optical
  - Foundation piles = geotechnical = Seine alluvium (borehole logs, 20 m depth)
  - Floor plates = FEM mesh = vibration modes (generator 0.5 Hz, avoiding resonance)
  - Curtain walls = unit cell = lead-lined brick (vitriol resistance)
- **Observatory (Gay-Lussac's Domain):**
  - Window grid = observation log (lit = recording, dark = waiting, 0.1 Hz update)
  - Structural columns = instrument piers = vibration isolation (dip circle, barometer)
  - Dome = azimuth tracking = magnetic meridian alignment (72° dip, 14° W declination)
  - Rooftop = semaphore relay = Station 12 (visual + protonic optical)
- **Royal Society (Somerset House):**
  - Window grid = publication queue (lit = in press, dark = reviewed, Bakerian cycle)
  - Council Room = peer review = Copley Medal adjudication (Gay-Lussac 1806)
  - Library = knowledge graph = Philosophical Transactions (1665-present)
- **Académie des Sciences (Institut de France):**
  - Window grid = prize cycle (lit = adjudicating, dark = dormant, annual)
  - Salle des Séances = validation = *Mémoires* publication gate
  - Medal dies = certification = physical instantiation of peer review
- **Soho Gas Works (Boulton & Watt):**
  - Window grid = retort status (lit = charging, dark = carbonizing, 8 hr cycle)
  - Retort bench = 30 retorts = parallel hydrogen/coal gas production
  - Gasometer = telescopic = 500,000 ft³ = water seal pressure reference
  - Steam engine = Watt = beam engine = power as rotation = 20 HP

**Lonsdaleite Atmosphere — 1820s Specific — Detailed:**
- **Density Gradient:** Surface (2×10⁵/m³) → 7,016 m (5×10⁴/m³) — exponential decay with scale height 8 km
- **Multimodal Distribution Parameters:**
  - Mode 1 (vitriol aerosol): μ=0.01μm, σ=0.3, count=5×10⁴/m³, Channel 3 scatter
  - Mode 2 (FeSO₄ crystal): μ=0.05μm, σ=0.4, count=3×10⁴/m³, Channel 2 refract
  - Mode 3 (H₂ cluster): μ=0.1μm, σ=0.5, count=8×10⁴/m³, Channel 1 Raman
  - Mode 4 (silk varnish): μ=0.3μm, σ=0.3, count=2×10⁴/m³, Channel 8 fluoresce
  - Mode 5 (charcoal soot): μ=1μm, σ=0.4, count=1×10⁴/m³, Channel 0 absorb
  - Mode 6 (Paris fog): μ=10μm, σ=0.6, count=1×10⁴/m³, Channel 8 Mie
- **Orientation Tensor:** Anisotropic — generator plume (axial, 10 m/s), hydrogen drift (horizontal, 2 km/h), magnetic (dip 72°, 0.5 G), semaphore (vertical, 0.1 Hz)
- **Luminescence Spectra:** 
  - Vitriol: 520 nm (Channel 3, Mie scatter)
  - FeSO₄: 460 nm (Channel 2, crystal refract)
  - H₂: 410 nm (Channel 1, Raman shift)
  - Silk: 580 nm (Channel 8, varnish fluorescence)
  - Gaslight: 600 nm (Channel 8, flame emission)
- **1820s Lonsdaleite Formation Sites:**
  - Generator cooling jacket: Fe + H₂SO₄ + 10 bar shock → hexagonal diamond in scale (Channel 8, 10 m visibility)
  - Envelope silk: H₂ + UV + pressure cycling → hexagonal diamond in varnish (Channel 8, 5 m visibility)
  - Gasometer frame: Fe + H₂O + pressure cycling → hexagonal diamond in rust (Channel 8, 50 m visibility)
  - Dip circle bearing: agate + magnetic + shock → hexagonal diamond in jewel (Channel 13, 1 m visibility)

**Toxic Element Geometry (Background Intrusions) — Detailed:**
1. **Vitriol Chamber Rupture:** Conic intrusion (apex at chamber, 45° half-angle, 50 m radius) — Channel 0 (thermal, 100°C acid) + Channel 14 (chem, 90% H₂SO₄) + Channel 15 (human, 50 injured). Stopped by MXene catalytic neutralization (H₂SO₄ → H₂O + SO₃).
2. **Gasometer Collapse:** Spherical intrusion (center at bell, 200 m radius) — Channel 0/14 (H₂ fireball, 2000 m/s) + Channel 15 (human). Stopped by MXene catalytic recombination (H₂ → H₂O).
3. **Generator Overpressure:** Cylindrical intrusion (axis = hopper, 30 m radius, 50 m/s fragments) — Channel 9/10 (kinetic, 500 kg Fe) + Channel 15. Stopped by auxetic cladding (ν=-0.5, blast absorption).
4. **Semaphore Severed:** Planar intrusion (plane = telegraph line, 10 km × 100 m) — Channel 8 (information loss) + Channel 15 (navigation blind). Stopped by protonic optical backup (520 nm, line-of-sight).
5. **Académie Rejection:** Point intrusion (origin = Institut, expands at 0.1 m/s) — Channel 8 (institutional silence) + Channel 15 (priority dispute). Stopped by Royal Society parallel publication (Bakerian Lecture).

**Era-Text Integration — 1820s Lithographic Poster / Fat-Face / Exhibition Handbill / Scientific Proceedings — Complete Set:**
- **Poster Headlines (Fat Face, 72pt, Charcoal Iron + Sulfuric Yellow):**
  - "HYDROGEN BALLOON. SCIENCE ASCENDS."
  - "CHARLES. ROBERT. GAY-LUSSAC. THE TRIUMVIRATE."
  - "7,016 METRES. THE RECORD STANDS."
  - "IRON. VITRIOL. GAS. THE CHEMISTRY OF FLIGHT."
- **Exhibition Handbills (Lithographic, 24pt, Stone Grey on Cream):**
  - "ASCENT THIS AFTERNOON. TUITIERES. 2 PM."
  - "GAY-LUSSAC. SOLO. 7,016 M. MAGNETIC DIP."
  - "PURE HYDROGEN. GENERATED DAILY. 25 M³/HR."
- **Scientific Memoirs (Engraved, 10pt, Rich Black on Wove):**
  - "Mémoire sur l'ascension aérostatique de 1804. Par M. Gay-Lussac."
  - "Bakerian Lecture, 1805. On the Magnetic Phenomena at Great Elevations."
  - "Philosophical Transactions, Vol. 96. The Constancy of Magnetic Dip."
- **Gas Works Advertisements (Commercial, 18pt, Hydrogen Blue on Cream):**
  - "Charles's Hydrogen Apparatus. 25 m³/hr. Purity 98%. Tuileries."
  - "Soho Gas Works. Coal Gas & Hydrogen. Boulton & Watt Engine."
- **Aeronaut Certificates (Calligraphic, 14pt, Royal Society Crimson Seal):**
  - "Certificat d'Ascension. Charles. Robert. 1 Décembre 1783."
  - "Certificate of Ascent. Gay-Lussac. 7,016 Metres. 1804."
- **Specification Tables (Ledger, 9pt, Hairline Rules):**
  - As defined in previous piece (PARAMETER / VALUE / UNIT table)