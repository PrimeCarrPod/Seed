### IV. EXPOSE WINDOWS — 1820s HYDROGEN AEROSTATION TRUTH

**Window Count:** 2 ± 1 (Poisson λ=2). Typical: 2 windows (1820s: hydrogen plant + scientific observation).

**1820s-Specific Content Weighting:**
- **Envelope / Hydrogen / Structural / Generation** (50%): Envelope tension (silk, 25 g/m², rubber/turpentine varnish, 8 coats), hydrogen purity (98% H₂, 2% air/CO₂/H₂S), pressure differential (25 mm H₂O), valve function (brass, 0.5 m², 10% open), **hydrogen generation** — iron feed rate (500 kg/hr), vitriol concentration (90% H₂SO₄), generator pressure (1.2 bar), condenser efficiency (50% acid recovery), **structural** — net tension (hemp, 60 km), car suspension (4-point, wicker).
- **Meteorological / Scientific / Magnetic / Barometric** (30%): Altitude (5,200 m), pressure (420 mmHg), temperature (-12°C), hygrometry (20%), magnetic dip (72°), declination (14° W), air composition (O₂ 21%, N₂ 78%, Ar 1%), lapse rate (6.5°C/km), **scientific instruments** — barometer (Fortin, 0.1 mmHg), thermometer (mercury, 0.1°C), magnetometer (Borda dip circle, 0.1°), flasks (evacuated, 5,200 m air).
- **Ballast / Economy / Ascent / Chemical** (20%): Sand remaining (200 kg), iron filings (100 kg), vitriol (500 L), lever clicks (40), valve position (15% open), ascent rate (2 m/s per 25 kg), descent rate (1 m/s per 10 mm H₂O), flight duration (2 hr), **chemical stoichiometry** — Fe consumed (mol), H₂ generated (mol), FeSO₄ produced (mol), acid recovered (L).

**1820s-Specific Window Types:**
1. **Hydrogen Plant & Envelope Monitor** — Real-time strain gauge (12 envelope panels), safety factor 2.0, redline 300 N/50 mm, sampling 10 Hz, trend 60 sec, generator pressure (1.2 bar), iron feed (500 kg/hr), vitriol concentration (90%), condenser temp (40°C), acid recovery (50%), hydrogen purity (98%), envelope pressure (25 mm H₂O), valve position (15% open), **structural integrity** — net panel load (200 N), car suspension load (250 N each).
2. **Scientific-Vector & Atmospheric Station** — Altitude (5,200 m), pressure (420 mmHg), temp (-12°C), humidity (20%), magnetic dip (72°), declination (14° W), air sampling (flask 3/6), lapse rate (6.5°C/km), **semaphore bearing** (Chappe station 12, Paris-Lille, strength 4/5), **observatory log** (Gay-Lussac 1804, dip constant), **chemical log** (Fe 8.9 mol, H₂ 8.9 mol, FeSO₄ 8.9 mol).

**Overlap Rules (1820s Hydrogen Aerostation):**
- Windows may overlap **1-deep maximum** (1820s: "MEASUREMENTS DO NOT OVERWRITE")
- Overlap region shows **THEMATIC RESONANCE** (scientific fusion): data from both windows renders as **mémoire fusion** — "ALT 5200 M. PRESS 420 MMHG. H₂ 98%. FE 8.9 MOL. DIP 72°."
- Priority: **Hydrogen+Envelope > Scientific+Atmospheric > Ballast+Chemical**
- Neon outline **thins to 0.5px** in overlap zones (1820s: "THE FUSION IS MEASURED")
- Zero-padding frame: **content bleeds to edge** — no margin, the measurement *is* the record

**Animation / Alive Behavior:**
- Hydrogen Plant monitor: **pulses at 0.5 Hz** (iron filings feed rhythm), amplitude = pressure variance; **chemical rhythm** (stoichiometric pulse per mole, outline blinks hydrogen blue)
- Scientific-Vector station: **updates at 0.1 Hz** (1820s: "OBSERVATION PER 10 SEC") — scientific log rate, barometer click audible
- Valve breathing: **0.001 Hz** (envelope pressure diurnal), visible in Channel 15 modulation
- Magnetic dip: **0.0001 Hz** (diurnal variation), visible in Channel 13 harmonic
- Semaphore click: **0.1 Hz** (Chappe), visible in Channel 8 modulation
- Atmospheric: **static unless change >2%** (1820s: "THE SCIENCE IS PRECISE")
- Citadel Ground: **steady green pulse at 7.83 Hz** (Schumann lock)

**Window Rendering Styles (1820s Specific):**
- Window 1 (Hydrogen Plant): **Technical line drawing** (white on transparent, 0.5px stroke) — 1820s engineering plate, *Description des Arts et Métiers* style
- Window 2 (Scientific-Vector): **Mathematical notation** (LaTeX/KaTeX rendered to texture) — theoretical physics, *Mémoires de l'Académie* style
- Both: **Projection matrices** — Window 1: 16→3 seeded by generator hash; Window 2: 16→3 seeded by observatory hash — different color mappings, moiré at overlap

**Window Boundaries (1820s Shape Distribution):**
- Hexagon (60%) — aligned to lonsdaleite lattice, hydrogen crystal symmetry
- Voronoi cell (20%) — seeded by PVDF-TrFE node positions (80 nodes)
- Fractal boundary (10%) — Sierpiński carpet iteration 3, iron filings pattern
- Schumann waveform (10%) — 7.83 Hz sinusoid extruded along normal, magnetic dip modulation