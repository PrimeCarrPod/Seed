### II. THE SUBJECT — CONTINUED (HELMET, GLOVES, BOOTS, POSE, NEON OUTLINE, TOXIC ELEMENTS)

**Helmet (CSM_GEN_N-HLM-1820s) — Detailed Specification:**
- **Crown:** Silk top hat (4mm, charcoal iron black, Victorian stove-pipe profile) — ZrB₂-SiC ceramicized silk, thermal emissivity 0.5 at -20°C, structural backup for valve key impact
- **Brim:** Reinforced with Ti₃AlC₂ MAX phase ring (2mm, continuous, hydrogen valve key attachment point) — doubles as valve wrench socket
- **Visor/Goggles:** Brass rim (40mm, turned, knurled grip) + smoked glass (4mm, cobalt blue filter, Channel 2/3 modulation) + anti-fog (Channel 7, MXene heating trace, 5V) + pressure equalization vents (4× 2mm, Channel 15)
- **Valve Key:** Brass (functional, 19mm square drive, generator feed coupling) — integrated into brim ring, Channel 12 pressure transduction, tactile feedback at 0.1 bar resolution
- **Barometer Eyepiece:** MXene-printed (Channel 15, 0-8000 m, mercury-equivalent) — projects on goggle lens, updates at 0.1 Hz, audible click at 100 m intervals
- **Magnetometer Needle:** Gimballed (50 mm, jeweled bearing, Channel 13 magnetic domain visualization) — dip angle 72° at Paris, declination 14° W, updates at 1 Hz
- **Rosettes:** Royal Society (silk, crimson, Fellow's badge, 30mm) + Académie des Sciences (silver, engraved, Gay-Lussac 1804, 25mm) — Channel 8 lonsdaleite scattering at edges
- **Speaking Tube:** Brass (1 m, condenser drain integrated) — connects to ground observatory, protonic optical backup (520 nm)

**Glove System — Detailed Specification:**
- **Base Layer:** STF-UHMWPE (shear-thickening, 2mm) — flexible at rest, rigid at impact > 50 J
- **Ceramic Scales:** ZrB₂-SiC (dorsal, articulated, 150mm × 150mm × 3mm) — Knoop 2200, hydrogen permeation barrier
- **Fingertip Caps:** Brass (turned, knurled, Channel 12 piezoelectric) — hydrogen valve tactile feedback, pressure transduction 0-10 bar
- **Palm:** Bare MXene capacitive (Channel 1/2) — feel gas pressure vibration, valve seat contact, rope texture
- **Cuff:** Brass braid (aeronaut's rank, 3 strands = scientific observer) + hydrogen line quick-disconnect (Ti₃AlC₂, self-sealing)
- **Lacing:** Dyneema SK99 (12 zones, Ti₃AlC₂ cleats) — tension calibrated per LE-TG spec

**Boot Integration — Detailed Specification:**
- **Upper:** Hessian leather (full-grain, 3mm, brass toe cap) — ZrB₂-SiC ceramic toe/heel inserts
- **Sole:** Vibram-style basalt fiber composite (Elium® thermoplastic, 10mm) — hobnail pattern (20× Ti₃AlC₂ studs)
- **Hydrogen Connectors:** Ti₃AlC₂ quick-disconnect (male/female, self-sealing, 10 bar rated) — generator feed + envelope sample line
- **Ballast Hooks:** Brass (functional, 4× per boot, 25 kg rated) — sandbag attachment, quick-release lever
- **Anchor Cleat:** Brass (functional, horn-type, 500 m hemp rope rated) — ground tether, Channel 11 inertial monitoring
- **Lacing:** Dyneema SK99 + MR fluid bladder (ankle support, Channel 7 magnetochromic)

**Pose — THE SCIENTIFIC AERONAUT'S OBSERVATION — Biomechanical Detail:**
- **Center of Mass:** (3840, 2160) ± 10px — aligned to frame center per Master Composition
- **Left Arm:** Extended 15° from vertical, elbow 170°, forearm pronated 45°, hand on valve lever — grip force 25 N, Channel 12 reads 1.2 bar
- **Right Arm:** Raised 45° from horizontal, elbow 90°, forearm supinated 90°, hand on barometer — mercury column visible, Channel 15 reads 420 mmHg
- **Torso:** Forward lean 8° — weight committed to observation, not heroics
- **Legs:** Left knee 160° (braced), right knee 175° (extended) — dynamic stability in basket
- **Head:** Tilt 10° right, chin down 5° — eyes on magnetometer needle (dip 72°), barometer eyepiece (5200 m)
- **Micro-expressions:** Brow furrow 2mm (concentration), jaw set (breathing control), pupil dilation 6mm (dark adaptation at altitude)

**Neon Outline — 1820s Modulation — Spectral Detail:**
- **Base Frequency:** 7.83 Hz (Schumann fundamental) — Channel 8 lonsdaleite scattering
- **Hydrogen Generation Rhythm:** 0.5 Hz (iron filings feed, 25 m³/hr) — outline amplitude ±0.3px at feed pulses
- **Valve Breathing:** 0.001 Hz (envelope pressure diurnal) — outline thickness varies ±0.1px over 1000 sec
- **Magnetic Dip Oscillation:** 0.0001 Hz (diurnal variation ±0.1°) — outline hue shift in Channel 13 (magnetic domain)
- **Pilot HRV:** 60 bpm (1 Hz) + LF/HF 2.5 — outline micro-flicker at cardiac harmonics
- **Frame Contact Points (3):** Left shoulder (x=200), Right hip (x=7480), Crown (y=200) — outline continues beyond frame, clipped at sensor edge

**Five Toxic Elements — Geometric Intrusion Detail:**
1. **Generator Explosion:** Conic intrusion from lower-left (generator position) — Channel 0 (thermal) + Channel 14 (chem) vertices, stopped at ZrB₂-SiC lamina by MXene catalytic dome (recombination radius 0.5 m)
2. **Hydrogen Fire:** Spherical intrusion from envelope (above) — Channel 0/14 flame front, 2000 m/s, stopped by MXene catalytic surface (recombination rate 10⁶ mol/m²/s)
3. **Valve Failure:** Cylindrical intrusion from valve (left hand) — Channel 9/10 pressure wave, stopped by auxetic cladding (negative Poisson's ratio -0.5)
4. **Ballast Exhaustion:** Planar intrusion from floor (sand bags) — Channel 11 inertial gradient, stopped by PVDF-TrFE vestibular lock (attitude hold 0.1°)
5. **Psychological Burden:** Spherical intrusion from crown (isolation) — Channel 15 infrasound 18 Hz, stopped by MR fluid counter-phase (destructive interference 140 dB)

Each intrusion renders as **distinct geometric primitive** (cone, sphere, cylinder, plane, sphere) with **unique Channel signature** — the suit *reads* the threat by its geometry.