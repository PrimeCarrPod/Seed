### III. BACKGROUND CHAOS — 1820s PARIS / GAS WORKS / SCIENTIFIC SOCIETIES / HYDROGEN FEVER DREAM

**Procedural Grammar — Aerostation as Hydrogen Topology:**

Every structure in the background is **1820s hydrogen generation infrastructure** (1820-1829) — the vitriol chambers and iron filings hoppers that *made the sky a measurable domain*. Generated from a **context-free grammar** encoding **Charles's Tuileries / Gay-Lussac's Observatory / Royal Society / Académie des Sciences / Soho Gas Works topology** as spatial layout:

**Narrative Elements as Chapter Nodes (weighted random):**
- **Charles & Robert / Tuileries / Paris Gas Works (25%)** — **First Hydrogen Balloon *Globe* (1783, 27 min, 21 km)** — iron filings (500 kg) + sulfuric acid (2,500 L) → hydrogen (25 m³/hr), silk envelope (3,000 m³), varnish (rubber/turpentine), valve (brass, 0.5 m²), car (wicker, 2 aeronauts), **first passengers (Charles, Robert, 1783-12-01)**.
- **Gay-Lussac / Scientific Ascents / 7,016 m Record (20%)** — **1804 Flights (2 ascents, solo + Biot)** — magnetometer (dip needle), barometer (mercury), thermometer (mercury), hygrometer (hair), air sampling (flasks, 7,016 m), *Mémoires de l'Académie des Sciences* (1806, "Mémoire sur la chaleur"), **temperature lapse rate measured**, **magnetic dip constant with altitude**.
- **Royal Society / Académie des Sciences / Lunar Society (15%)** — **Instruments & Proceedings** — barometer (aneroid prototype, 0.1 mmHg), thermometer (mercury, 0.1°C), magnetometer (dip circle, 0.1°), hygrometer (Saussure hair), **Royal Society Bakerian Lecture** (1805, Gay-Lussac), **Académie Prix** (1805, hydrogen properties), **Lunar Society** (Priestley, Watt, Darwin — gas chemistry roots).
- **Continental Gas Works / Soho / Vauxhall / Paris (15%)** — **Coal Gas vs Hydrogen** — telescopic gasometer (50,000 ft³), retort bench (coal, 500°C), purifier (lime/iron oxide), **Soho Gas Works** (Boulton & Watt, 1805), **Vauxhall** (Green, 1816+), **Paris Gas Works** (Charles's generator), *gaslight* = public revenue, *hydrogen* = scientific lift.
- **Early Dirigible Concepts / Meusnier / Willard (15%)** — **Propulsion & Form** — Meusnier (1784, ellipsoid envelope, internal ballonet, oar propulsion), Willard (1824, steam engine, propeller, *Aerial Steam Carriage* precursor), **internal ballonet** = pressure maintenance, **ellipsoid** = aerodynamic form, **propeller/oar** = thrust vector.
- **Public Spectacle / Lunardi / Blanchard / Garnerin (10%)** — **Exhibition & Celebrity** — Lunardi (1784, London, 150,000 spectators), Blanchard (1785, Channel crossing, 1785-01-07), Garnerin (1797, parachute, 1797-10-22), **exhibition handbills** (lithographic, fat-face, "ASCENT THIS AFTERNOON"), **aeronaut celebrity** = public science.

**Infrastructure as Information Carrier:**
- **Vitriol Chambers** = **chemistry as architecture** — lead chambers (90% H₂SO₄), nitrogen oxides catalyst, sulfur dioxide + water + NO → H₂SO₄, **Charles's generator** = iron filings hopper (500 kg) + vitriol feed (2,500 L) → H₂ (25 m³/hr), **heat** = exothermic (ΔH = -85 kJ/mol).
- **Hydrogen Generator** = **stoichiometry as structure** — Fe + H₂SO₄ → FeSO₄ + H₂ (1:1:1:1 molar), 56 g Fe → 22.4 L H₂ at STP, **purity** = 98% (2% air, CO₂, H₂S), **cooling** = water jacket (condenser, 50% acid recovery).
- **Gasometer** = **storage as telescope** — telescopic frame (3 lifts, 50,000 ft³ each), water seal, **hydrogen** = dedicated bell, **coal gas** = public supply, **pressure** = 25 mm H₂O constant.
- **Scientific Instruments** = **measurement as machinery** — barometer (Fortin, mercury, 0.1 mmHg), thermometer (Réaumur/mercury, 0.1°), magnetometer (Borda dip circle, 0.1°), hygrometer (Saussure, hair), **all calibrated at Académie / Royal Society**.
- **Telegraph Towers (Semaphore)** = **communication as navigation** — Chappe semaphore (1792, Paris-Lille, 230 km, 15 stations), **aerial signal** = position/altitude/wind, **observer** = Gay-Lussac at 7,016 m sees 300 km horizon.

**Buildings as Data Structures (1820s Specific):**
- **Tuileries Generator Shed:** **Reaction = proof** — iron filings hopper (volumetric, 500 kg), vitriol chamber (lead, 2,500 L), gas outlet (copper, 50 mm), cooling jacket (water, 50% recovery), **Charles's signature** = traceability.
- **Observatory / Gay-Lussac's Laboratory:** **Measurement = authority** — dip circle (Borda, gimballed), barometer (Fortin, temperature compensated), flasks (evacuated, 7,016 m air), **Académie seal** = validation.
- **Royal Society / Somerset House:** **Peer review = institution** — Council Room (Bakerian Lecture), Library (Philosophical Transactions), **Medal** = certification (Copley, Gay-Lussac 1806).
- **Académie des Sciences / Institut de France:** **State science = sponsor** — Salle des Séances (prize adjudication), *Mémoires* = publication, **Prix** = certification (1805, hydrogen).
- **Soho Gas Works / Boulton & Watt:** **Industry = scale** — retort bench (30 retorts, coal), gasometer (telescopic, 500,000 ft³), purifier (lime), **steam engine** = Watt, **gaslight** = revenue.
- **Jardin des Plantes / Paris:** **Botany + Chemistry = unity** — Lavoisier's laboratory (preserved), gas experiments, **hydrogen** = element (Lavoisier 1783, "hydro-gène").

**Lonsdaleite Atmosphere — 1820s Specific:**
- Particle density: **2×10⁵ particles/m³** (iron filings dust + sulfuric acid mist + hydrogen gas + silk varnish + charcoal soot + Paris fog)
- Size distribution: **hydrogen generation multimodal** — mode 1: 0.01μm (H₂SO₄ aerosol, vitriol chamber), mode 2: 0.05μm (FeSO₄ crystal, generator effluent), mode 3: 0.1μm (H₂ gas cluster, envelope permeation), mode 4: 0.3μm (silk dust, varnish, envelope), mode 5: 1μm (charcoal soot, Paris heating), mode 6: 10μm (Paris fog, hygroscopic, Seine mist)
- Orientation: **aligned by generator plume / hydrogen drift / magnetic field / semaphore EM** — generator plume 10 m/s axial, hydrogen drift 2 km/h, magnetic 0.5 G, semaphore 0.1 Hz
- Luminescence: **vitriol aerosol scatter** (Channel 3, 520 nm), **FeSO₄ crystal refract** (Channel 2, 460 nm), **H₂ cluster Raman** (Channel 1, 410 nm), **silk varnish fluorescence** (Channel 8, 580 nm), **gaslight flicker** (Channel 8, 600 nm)
- **1820s phenomenon:** **Generator lonsdaleite** — iron + H₂SO₄ + shock in cooling jacket → microscopic hexagonal diamond in scale, visible in Channel 8 at 10 m; **Envelope lonsdaleite** — silk + H₂ + varnish + UV + pressure cycling → microscopic hexagonal diamond in fabric, visible in Channel 8 at 5 m; **Gasometer lonsdaleite** — iron + water seal + pressure cycling + weathering → microscopic hexagonal diamond on frame, visible in Channel 8 at 50 m.

**Toxic Element Geometry (Background Intrusions — Narrative Hazards):**
1. **Vitriol Chamber Rupture / Acid Cloud:** **Lead chamber fails** (90% H₂SO₄, 2,500 L, 50 m radius, 10 min dispersion, 50 injured) — Color: Channel 0/14 (chem/thermal) + Channel 15 (human).
2. **Gasometer Collapse / Hydrogen Cloud:** **Telescopic frame buckles** (50,000 ft³ H₂ release, 200 m radius, 30 min dispersion, ignition → 500 m fireball) — Color: Channel 0/14 (chem/thermal) + Channel 15 (human).
3. **Generator Overpressure / Iron Filings Shrapnel:** **Hopper blocks, pressure spikes** (10 bar, 500 kg Fe, 50 m/s fragments, 30 m radius, 3 killed) — Color: Channel 9/10 (kinetic/structural) + Channel 15 (human).
4. **Semaphore Line Severed / Navigation Blind:** **Chappe arm parts in storm** (position lost, aeronaut 30 min blind, forced landing) — Color: Channel 8 (information) + Channel 15 (human).
5. **Académie Rejects / Priority Dispute:** **Council votes against publication** (Gay-Lussac 1804 data withheld, Biot claims priority, science delayed) — Color: Channel 8 (institutional) + Channel 15 (human).

**Era-Text Integration (1820s Lithographic Poster / Fat-Face Display / Exhibition Handbill / Scientific Proceedings):**
- **Lithographic Poster Headline:** "HYDROGEN BALLOON ASCENT. CHARLES. ROBERT. GAY-LUSSAC. PARIS. TUITIERES. 7,016 METRES. THE GAS IS PURE. THE INSTRUMENTS RECORD. THE SCIENCE ADVANCES."
- **Exhibition Handbill:** "GRAND ASCENT. MONDAY NEXT. HYDROGEN GENERATED ON SITE. IRON FILINGS. VITRIOL. SILK ENVELOPE. VALVE. BAROMETER. THERMOMETER. MAGNETOMETER. ADMIT ONE SHILLING."
- **Académie des Sciences Mémoire:** "MÉMOIRE SUR L'ASCENSION AÉROSTATIQUE DE 1804. J.L. GAY-LUSSAC. ALTITUDE: 7,016 M. TEMPÉRATURE: -20°C. PRESSION: 380 MMHG. AIGUILLE AIMANTÉE: INCLINAISON CONSTANTE. COMPOSITION DE L'AIR: INVARIABLE."
- **Royal Society Proceedings:** "BAKERIAN LECTURE, 1805. MR. GAY-LUSSAC. ON THE MAGNETIC AND THERMAL PHENOMENA OBSERVED AT GREAT ELEVATIONS. THE MAGNETIC DIP IS INDEPENDENT OF ALTITUDE. THE TEMPERATURE DECREASES UNIFORMLY."
- **Gas Works Advertisement:** "PURE HYDROGEN GAS. FOR AEROSTATIC PURPOSES. GENERATED DAILY. IRON + VITRIOL. 25 M³/HR. PURITY GUARANTEED 98%. CHARLES'S APPARATUS. TUITIERES."
- **Aeronaut Certificate:** "CERTIFICATE OF ASCENT. JACQUES ALEXANDRE CÉSAR CHARLES. NICOLAS-LOUIS ROBERT. PARIS, 1 DECEMBRE 1783. DURATION: 27 MINUTES. DISTANCE: 21 KM. ALTITUDE: 500 M. WITNESSES: 400,000."
- **Specification Table:** "PARAMETER / VALUE / UNIT / ENVELOPE VOLUME / 3000 / M³ / HYDROGEN PURITY / 98 / % / GENERATION RATE / 25 / M³/HR / IRON FILINGS / 500 / KG / VITRIOL / 2500 / L / VALVE DIAMETER / 0.5 / M² / MAX ALTITUDE / 7016 / M / MIN TEMPERATURE / -20 / °C / MAGNETIC DIP / 72 / ° / FLIGHT DURATION / 2 / HR"