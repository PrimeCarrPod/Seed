# CLPS Phase 2 Cascade — Part 10: Contractor Technical Interchange Meetings — Piece 10/34
## Episode: The Handshake — TIM Campaign CSM-CLPS-TIM-001 through 003
**Piece:** 10 of 34  
**Generated:** 2026-08-27 00:35:00 UTC  
**Author:** Jason Isaac Brodsky (California 1976) — Conducier  
**Heuristics:** Williams Paradise Man V3 EXTREME + El Segundo EXTREME  

---

**10.**

KADE here. The Lighthouse. TIM-002: Firefly Aerospace. Cedar Park, Texas. Blue Ghost lander. The propulsion team. Chief Engineer: Will Coogan. Thirty-nine. Former SpaceX Raptor. Intensity of a supernova. The Article 2 crate: Pressure Vessel Quarter-Section. Eighteen kg. Five hundred mm radius. Co-cured titanium flanges. The Firefly team: their current propellant tanks — composite overwrapped pressure vessels (COPV). Aluminum liner. Carbon fiber overwrap. Separate titanium flanges, bolted. Mass: forty-two kg per quarter. Four quarters per tank. One hundred sixty-eight kg per tank. Two tanks per lander. Three hundred thirty-six kg. Ours: monolithic LBFRP-001. Co-cured flanges. Eighteen kg per quarter. Seventy-two kg per tank. One hundred forty-four kg per lander. Fifty-seven percent mass savings. One hundred ninety-two kg returned to propellant/payload. Will Coogan: "COPV qualification is a NIGHTMARE. Autofrettage. Acoustic emission. Liner buckling. Flange seal. Years of testing." KADE: "Our vessel: AFP laid. Hoop plus helical. Co-cured flanges. Proof tested: fifty-one bar. Burst: seventy-three bar. Digital twin predicted seventy-three. Zero liner (no liner to buckle). Zero autofrettage needed. Flange seal: molecular bond." Firefly test engineer: "Show me the burst data." KADE: "CT scan. Strain map. Acoustic emission log. All in the digital twin." Will Coogan stares at the burst pressure. Seventy-three bar. Design: thirty-four bar. Margin: two point one X. He says: "If this scales to full tank... we save two hundred kg. That's two hundred kg MORE PROPELLANT. That's MARGIN. That's MISSION SUCCESS." The Lighthouse shows the way. The ocean teaches: pressure is pressure. The tank holds.

PIECE_EOF