# CLPS Phase 2 Cascade — Part 10: Contractor Technical Interchange Meetings — Piece 20/34
## Episode: The Handshake — TIM Campaign CSM-CLPS-TIM-001 through 003
**Piece:** 20 of 34  
**Generated:** 2026-08-27 00:35:00 UTC  
**Author:** Jason Isaac Brodsky (California 1976) — Conducier  
**Heuristics:** Williams Paradise Man V3 EXTREME + El Segundo EXTREME  

---

**20.**

VEYNE here. Commander Auric Veyne. The Velvet Hammer. TIM negotiation outcomes. Intuitive Machines: Letter of Intent (LOI) for leg set + adapter for IM-3. Value: twelve million dollars. Timeline: PDR support Q1, CDR Q2, delivery Q4. Firefly Aerospace: LOI for vessel set + adapter for Blue Ghost 3. Value: fifteen million dollars. Timeline: scaling study Q1, PDR Q2, delivery Q3. Astrobotic: LOI for leg set + adapter for Griffin/VIPER. Value: eighteen million dollars (VIPER mission premium). Timeline: CDR integration Q1, delivery Q3. Total LOI pipeline: forty-five million dollars. Nine months to first delivery. The Velvet Hammer negotiates: data rights (contractor gets read-only digital twin for their articles). IP protection (process stays CSM, articles belong to contractor). Liability (CSM warrants process, contractor warrants integration). Production slots (AFP Network allocation reserved). The insurance gap: CLOSED. Premium reduction: forty to sixty percent. The carbon market: mass savings = carbon credits. The handshake has TERMS. The terms are FAIR. The Menehune build fair fishponds.

PIECE_EOF