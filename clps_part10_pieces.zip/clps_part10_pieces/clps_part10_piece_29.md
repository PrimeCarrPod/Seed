# CLPS Phase 2 Cascade — Part 10: Contractor Technical Interchange Meetings — Piece 29/34
## Episode: The Handshake — TIM Campaign CSM-CLPS-TIM-001 through 003
**Piece:** 29 of 34  
**Generated:** 2026-08-27 00:35:00 UTC  
**Author:** Jason Isaac Brodsky (California 1976) — Conducier  
**Heuristics:** Williams Paradise Man V3 EXTREME + El Segundo EXTREME  

---

**29.**

ARDEN here. The Whisper. AFP Network allocation from TIMs. IM: Facility 1 (PNW) — leg sets for IM-3, IM-4. Firefly: Facility 2 (Midwest) — vessels for Blue Ghost 3, 4. Astrobotic: Facility 1 (PNW) — leg sets for Griffin. Adapter: Facility 3 (Southeast) — universal adapters for all three. Draper: Facility 4 (West Coast) — all three articles. SpaceX: Facility 2 (Midwest) — Starship tank segments. Blue Origin: Facility 3 (Southeast) — Blue Moon adapters. Lockheed: Facility 4 (West Coast) — crewed lander articles. Sierra: Facility 3 (Southeast) — habitat adapters. ispace: Facility 5 (Japan) — all three articles (ITAR/EAR licensed). The AFP Network: FIVE facilities. SAME process. SAME digital twin. SAME verification. CAPACITY: seven hundred fifty lander sets per year. The CLPS manifest: NINE landers. We have CAPACITY. The Menehune build in FIVE places. The fish don't care. They only know the pond holds.

PIECE_EOF