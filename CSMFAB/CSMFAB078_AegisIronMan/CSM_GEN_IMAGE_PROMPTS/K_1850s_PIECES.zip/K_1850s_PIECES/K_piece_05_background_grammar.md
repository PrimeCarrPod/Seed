---

### III. BACKGROUND CHAOS — 1850s LONDON / CRYSTAL PALACE / GREAT EXHIBITION FEVER DREAM

**Procedural Grammar — Aviation as Exhibition Topology:**

Every structure in the background is **1850s exhibition ballooning infrastructure** (1851-1859) — the gas works and glass palaces that *made the sky a public demonstration*. Generated from a **context-free grammar** encoding **Coxwell's Works / Paxton's Palace / Green's Vauxhall topology** as spatial layout:

**Narrative Elements as Chapter Nodes (weighted random):**
- **Coxwell's Balloon Works / London / New Cross** (25%) — **Great Balloon (100,000 ft³)** — silk envelopes (3,000 panels, Chinese silk, 25 g/m²), varnish (linseed, 6 coats), netting (hemp, 50 mm mesh, 100 km cord), car (wicker, 8 ft × 4 ft), appendix valve (brass, 1 m²), rip panel (silk, 2 m²), **coal gas inflation** (New Cross gas works, 50 t/day, 10,000 ft³/hr)
- **Great Exhibition / Crystal Palace / Hyde Park** (25%) — **Paxton's Palace** — ridge-and-furrow glass (293,655 panes, 49 in × 10 in), iron columns (3,300, cast), transept (108 ft span), nave (1,851 ft long), **Coxwell's Station** (north transept, dedicated inflation), commissioners' gallery (south transept), refreshment courts (center transept)
- **Scientific Societies / Royal Society / BAAS / Royal Institution** (20%) — **instruments** — barometer (aneroid, 0.1 mmHg), thermometer (mercury, -20 to +50°C), hygrometer (Regnault, 1%), magnetometer (dip circle, Gauss), **commissioners** — Airy, Sabine, Herschel, Faraday, **proceedings** — *Philosophical Transactions*, *BAAS Reports*, exhibition catalogue Class X
- **Charles Green / Nassau Balloon / Vauxhall Gardens** (15%) — **Royal Nassau Balloon (80,000 ft³)** — silk (2,400 panels), varnish (8 coats), netting (hemp, 60 km), car (gondola, 12 persons), valve (brass, 0.8 m²), **500 ascents without accident**, night ascents (fireworks, 1836-1852), parachute experiments (Cocking, 1837 — tragic)
- **Continental Exhibitions / Paris 1855 / Dublin 1853 / New York 1853** (15%) — **Palais de l'Industrie** (Paris, 1855), **Irish Industrial Exhibition** (Dublin, 1853), **Crystal Palace New York** (1853, burned 1858), **balloon ascents at each** (Godard, Poitevin, Nadar, Wise), international commissioners, comparative specifications

**Infrastructure as Information Carrier:**
- **Coal Gas Works** = **fuel as chemistry** — C + H₂O → CO + H₂ (water gas), CO + H₂O → CO₂ + H₂ (shift), purify → 50% H₂, 30% CH₄, 20% CO/N₂, lift 0.7 kg/m³ (vs 1.1 kg/m³ pure H₂), 100,000 ft³ = 70,000 kg gross, 50 t coal/day = 5 ascents/day
- **Great Balloon Envelope** = **structure as exhibition** — 3,000 silk panels, each 8 ft × 2 ft, varnish 6 coats = 400 kg, netting 100 km = 2,000 kg, car 500 kg, valve/rip 100 kg, total 3,000 kg empty, payload 12,000 kg (12 persons + instruments + ballast + exhibition exhibits)
- **Appendix Valve / Rip Panel** = **control as trust** — valve (brass, spring, 1 m², auto at 30 mm H₂O), rip (silk, 2 m², manual, emergency), pilot pulls → envelope opens → gas escapes → descent
- **Scientific Instruments** = **atmosphere as data** — barometer (720 mmHg = 1,500 m), thermometer (12°C), hygrometer (60%), magnetometer (dip 68°), **cyanotype camera** (1851, exhibition demonstration, first aerial cyanotypes)
- **Ballast / Ballast Lever** = **altitude as economy** — sand (30 bags × 25 kg = 750 kg), lever (graduated, 5 kg/click), release → ascent 1 m/s per 25 kg, valve → descent 1 m/s per 10 mm H₂O

**Buildings as Data Structures (1850s Specific):**
- **Coal Gas Works:** **Production = logistics** — coal (50 t/day, Newcastle), retorts (100, fireclay, 12 hr cycle), purifiers (lime, oxide, water), gasometer (50,000 ft³, telescopic), meter (dry, 10,000 ft³/hr), hose (gutta-percha, 500 m), **exhibition priority** (Coxwell = Class X, first inflation)
- **Crystal Palace:** **Glass = information** — panes (293,655 = bits), ridges (ridge-and-furrow = channels), transept (108 ft = bandwidth), nave (1,851 ft = latency), **commissioners' gallery** = peer review, **refreshment courts** = human factors, **Coxwell's station** = demonstration node
- **Royal Society / BAAS:** **Science = validation** — Airy (Astronomer Royal, barometer standard), Sabine (magnetic survey, dip circle), Herschel (photography, cyanotype), Faraday (electricity, atmospheric), **proceedings** = publication, **medals** = certification (Council Medal, Prize Medal)
- **Vauxhall Gardens:** **Pleasure = revenue** — Nassau Balloon (500 ascents = track record), night illuminations (fireworks = telemetry), music (orchestra = carrier wave), **Green's record** = safety case, **parachute tragedy** = risk disclosure (Cocking 1837, 80 m, failed)
- **Exhibition Catalogue:** **Specification = contract** — Class X (Philosophical Instruments), Coxwell entry (Great Balloon, 100,000 ft³, coal gas), Green entry (Nassau, 80,000 ft³, 500 ascents), **awards** = Council Medal (Coxwell), Prize Medal (Green), **catalogue number** = traceability