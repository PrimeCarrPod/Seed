# CSM_GEN_IMAGE_K_1850s
## Aegis Iron Man — 1850s Ballooning / Crystal Palace Exhibition / Great Exhibition Aesthetic
## 1850s Coxwell / Green / Paxton Aesthetic | Crystal Palace Exhibition Guide | Scientific Society Proceedings
## Exhibition Spectacle Meets Scientific Inquiry | Silk-Coal-Hydrogen Truth | Sky as Public Demonstration
## Liquid Hexadecimal AIMES Operator | Zero-Padding Frame | Overlapping Expose Windows
## Neon Subject Outline | Lonsdaleite Atmosphere | Background Chaos Directive
## Version 1.0 | August 2026 | For Ultra-High-Resolution 8K Portrait Generation

---

### I. THE SCENE — 1850s BALLOONING / CRYSTAL PALACE EXHIBITION / GREAT EXHIBITION AESTHETIC

**Semantic Gravity Well:** GLASS. IRON. COAL. HYDROGEN. The background chaos organizes around the physics of the first *systematic, public, exhibition* ballooning — not as war, not as romance, but as *aerial demonstration made spectacle where gravity is the challenge overcome and the crowd is the witness*. The 1850s Exhibition voice speaks in **catalogue precision**: "GREAT EXHIBITION. HYDE PARK. 1851. PAXTON'S PALACE. 900,000 SQUARE FEET. GLASS AND IRON. COXWELL ASCENTS. VAUXHALL. 10,000 SPECTATORS. THE ENGINEER RISES. THE PUBLIC WATCHES. THE SKY BELONGS TO THE EXHIBITION." Here: "ALTITUDE: 1,500 M. TEMPERATURE: 12°C. BAROMETER: 720 MMHG. THE AERONAUT DEMONSTRATES. THE INSTRUMENTS MEASURE. THE COMMISSIONERS RECORD. THE SKY BELONGS TO THE PUBLIC."

**Era-Vernacular Text Elements (1850s Crystal Palace Exhibition Guide / Royal Society Proceedings / Great Exhibition Catalogue):**
- **Headline Typography:** Fat Face / Egyptian / Tuscan — ALL CAPS, heavy display, ornamental serifs, black + exhibition gold, justified by crystal grid
- **Body Copy:** Scotch Roman / Ionic No. 5 — justified, 9pt, scientific terminology, footnotes to plates, "SEE PLATE XIV"
- **Callout Leaders:** Fine rules (0.3pt) with daggers († ‡ § ¶), exhibition authority, SMALL CAPS, 7pt, "OBS." "EXH." "COMM."
- **Specification Tables:** Exhibition ledger — ruled in hairline black + gold on white, calculated figures, metric + imperial, "PER ASCENT" "PER CUBIC FOOT"
- **Cutaway Illustrations:** Engineering plate style — sectional elevation, 0.2mm stroke, stipple for gas, cross-hatch for netting, "PLATE I" "PLATE II" "CRYSTAL PALACE"
- **Exhibition Plans:** Ground plan / Elevation — Paxton's ridge-and-furrow, transept, nave, "NORTH TRANSEPT" "SOUTH GALLERY" "COXWELL'S STATION"
- **Testimonials:** "H. COXWELL, LONDON — 'THE BALLOON IS A MACHINE OF PRECISION.'" "C. GREEN, VAUXHALL — 'FIVE HUNDRED ASCENTS WITHOUT ACCIDENT.'" "J. PAXTON, CHATSWORTH — 'GLASS AND IRON MAKE THE IMPOSSIBLE VISIBLE.'" — guillemets « », italic, engraved texture
- **Marginalia:** Equation refs, barometer corrections, "VOIR PLANCHE VII" cross-refs, exhibition class numbers, commissioner signatures

**Color Palette (1850s Crystal Palace Glass / Coal Smoke / Exhibition Gold):**
- **Crystal Palace Glass (PMS 5455)** — Paxton's ridges, transparency, the palace, the frame
- **Exhibition Gold (PMS 872)** — medal, gilding, catalogue trim, the award
- **Coal Smoke (PMS 426)** — London fog, gas works, netting, the reality
- **Scientific Blue (PMS 541)** — instruments, cyanotype, commissioners' sash, the method
- **Silk Natural (Unbleached)** — envelope, honesty, tensile truth, the vessel
- **Victorian Black (Rich Black)** — text, rigging, catalogue rule, the record
- **Paper Stock:** Laid finish, 100lb, visible chain lines, exhibition watermark (Prince Albert's profile), Great Exhibition folio simulation

---