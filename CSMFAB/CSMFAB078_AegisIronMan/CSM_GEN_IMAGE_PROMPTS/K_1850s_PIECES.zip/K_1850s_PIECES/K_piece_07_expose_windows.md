### IV. EXPOSE WINDOWS — 1850s EXHIBITION TRUTH

**Window Count:** 2 ± 1 (Poisson λ=2). Typical: 2 windows (1850s exhibition focus).

**1850s-Specific Content Weighting:**
- **Envelope / Gas / Structural / Exhibition** (45%): Envelope tension (varnished silk, 25 g/m², 6 coats), coal gas purity (50% H₂), pressure differential (30 mm H₂O), valve function, rip panel ready, netting load (hemp, 50 mm mesh), **exhibition payload** (commissioners, instruments, exhibits, weight distribution)
- **Meteorological / Scientific / Commission** (35%): Altitude (1,500 m), pressure (720 mmHg), temperature (12°C), hygrometry (60%), magnetometer (dip 68°), drift (8 km/h, NE), ground track, **commissioners' observations** (Airy barometer, Sabine dip, Herschel cyanotype)
- **Ballast / Economy / Ascent / Catalogue** (20%): Sand remaining (300 kg), lever clicks (60), valve position (15% open), ascent rate (1 m/s per 25 kg), descent rate (1 m/s per 10 mm H₂O), flight duration (2 hr), **catalogue entries** (Class X, 427, 428), **medals** (Council, Prize)

**1850s-Specific Window Types:**
1. **Envelope Integrity & Gas Monitor** — Real-time strain gauge (12 panels), safety factor 2.5, redline 400 N/50 mm, sampling 5 Hz, trend 120 sec, gas purity (H₂ 50%, CH₄ 30%), **exhibition payload weight** (12 persons + instruments = 1,200 kg), **commissioner position** (Airy port, Sabine starboard, Herschel aft)
2. **Meteorological-Exhibition Vector** — Altitude (1,500 m), pressure (720 mmHg), temp (12°C), humidity (60%), drift (8 km/h, 045°), ground speed (8 km/h), track (045°), compass (045° magnetic), magnetometer (dip 68°, intensity 0.45 G), **cyanotype exposure** (1/25 sec, f/8, Palace from 1,500 m), **catalogue log** (Class X entries, medals awarded)

**Overlap Rules (1850s Exhibition):**
- Windows may overlap **1-deep maximum** (1850s: "CATALOGUE ENTRIES DO NOT OVERWRITE")
- Overlap region shows **THEMATIC RESONANCE** (exhibition fusion): data from both windows renders as **catalogue fusion** — "ALT 1500 M. COAL GAS 50% H₂. COUNCIL MEDAL. CYANOTYPE PLATE VII."
- Priority: **Envelope+Gas > Meteorology+Science > Ballast+Catalogue**
- Neon outline **thins to 0.5px** in overlap zones (1850s: "THE FUSION IS CATALOGUED")
- Zero-padding frame: **content bleeds to edge** — no margin, the exhibition *is* the record

**Animation / Alive Behavior:**
- Envelope+Gas monitor: **pulses at 0.001 Hz** (envelope breathing, diurnal), amplitude = tension variance; **exhibition rhythm** (commissioner log entry per 30 min, outline blinks gold)
- Met-Exhibition vector: **updates at 0.01 Hz** (1850s: "OBSERVATION PER HOUR") — scientific log rate
- Netting creak: **2 Hz** (hemp cord), audible in outline harmonics
- Exhibition gaslight: **50 Hz flicker** (Palace gas lamps), visible in Channel 8 modulation
- Atmospheric: **static unless change >5%** (1850s: "THE SCIENCE IS PATIENT")
- Citadel Ground: **steady green pulse at 7.83 Hz** (Schumann lock)

------