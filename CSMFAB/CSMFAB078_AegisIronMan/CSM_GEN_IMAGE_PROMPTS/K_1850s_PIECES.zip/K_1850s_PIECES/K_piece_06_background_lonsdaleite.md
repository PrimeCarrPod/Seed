**Lonsdaleite Atmosphere — 1850s Specific:**
- Particle density: **2×10⁵ particles/m³** (coal soot + hydrogen mist + silk dust + exhibition glass dust + London fog)
- Size distribution: **exhibition multimodal** — mode 1: 0.02μm (coal soot, gas works), mode 2: 0.2μm (H₂O/H₂S aerosol, generator), mode 3: 0.5μm (silk dust, varnish), mode 4: 1μm (glass dust, Crystal Palace panes), mode 5: 10μm (London fog, hygroscopic)
- Orientation: **aligned by wind / envelope breathing / exhibition glass EM field** — drift 8 km/h axial, thermal 0.3 m/s, envelope pulse 0.001 Hz, palace glass 50 Hz hum
- Luminescence: **coal soot absorb** (Channel 0, 400 nm), **hydrogen mist scatter** (Channel 3, 520 nm), **exhibition glass** (Channel 2, 460 nm), **crowd gaslight** (Channel 8, specular)
- **1850s phenomenon:** **Coal gas lonsdaleite** — coal gas + combustion + shock in retort → microscopic hexagonal diamond in purifier, visible in Channel 8 at 30 m; **Silk lonsdaleite** — silk + varnish + UV + tension → microscopic hexagonal diamond on envelope, visible in Channel 8 at 20 m; **Glass lonsdaleite** — sheet glass + coal smoke + 50 Hz EM + weathering → microscopic hexagonal diamond on panes, visible in Channel 8 at 100 m

**Toxic Element Geometry (Background Intrusions — Narrative Hazards):**
1. **Gas Works Explosion / Retort Failure:** **Coal gas overpressure** (100 retorts, 1200°C, purifier bursts, 500 m radius, 50 t coal/day → 0) — Color: Channel 0/14 (thermal/pressure).
2. **Great Balloon Fire / Static:** **Envelope tear + spark** (100,000 ft³ coal gas, 50% H₂, 2,000 m/s, car 30 ft below, 3 officers, 3 sec) — Color: Channel 0/14 (thermal/chem) + Channel 15 (human).
3. **Valve Jam / Envelope Burst Over Palace:** **Appendix valve freezes** (30 mm H₂O → 200 mm H₂O, silk fails at 150 mm H₂O, 100,000 ft³ → 0 in 15 s, 4,000 m free fall, Hyde Park) — Color: Channel 9/10 (structural) + Channel 15 (human).
4. **Crowd Surge / Inflation Site Collapse:** **Barrier fails** (10,000 spectators, 20 m/s surge, 50 injured, rope barrier 500 N, inflation delayed 2 hr, commissioners evacuate) — Color: Channel 14 (kinetic) + Channel 15 (human) + Channel 8 (information).
5. **Thames Descent / River Hazard:** **Balloon lands in river** (current 2 m/s, width 200 m, tide 4 m, 3 officers, car not watertight, 10 min to rescue) — Color: Channel 9/10 (hydro/structural) + Channel 15 (human).

**Era-Text Integration (1850s Crystal Palace Exhibition Guide / Royal Society Proceedings / Great Exhibition Catalogue):**
- **Exhibition Catalogue Entry:** "CLASS X — PHILOSOPHICAL INSTRUMENTS. NO. 427. H. COXWELL, LONDON. GREAT BALLOON. VOLUME 100,000 CUBIC FEET. SILK 3,000 PANELS. COAL GAS INFLATION. COUNCIL MEDAL." "CLASS X — NO. 428. C. GREEN, VAUXHALL. NASSAU BALLOON. VOLUME 80,000 CUBIC FEET. 500 ASCENTS. PRIZE MEDAL."
- **Commissioners' Report:** "ROYAL COMMISSION. 1851. ASCENT NO. 1. COXWELL GREAT BALLOON. ALTITUDE 1,500 M. BAROMETER 720 MMHG. TEMPERATURE 12°C. MAGNETIC DIP 68°. CYANOTYPE PLATES 12. COMMISSIONERS AIRY, SABINE, HERSCHEL. REPORT TO PRINCE ALBERT."
- **Aeronaut Card:** "HENRY COXWELL / LONDON / AERONAUT / GREAT BALLOON 100,000 FT³ / 'THE BALLOON IS A MACHINE OF PRECISION, NOT A TOY OF CHANCE.'" "CHARLES GREEN / VAUXHALL / AERONAUT / NASSAU BALLOON 80,000 FT³ / 'FIVE HUNDRED ASCENTS WITHOUT ACCIDENT. SAFETY IS THE FIRST SCIENCE.'" "JOSEPH PAXTON / CHATSWORTH / ARCHITECT / CRYSTAL PALACE 900,000 FT² / 'GLASS AND IRON MAKE THE IMPOSSIBLE VISIBLE.'"
- **Specification:** "GREAT BALLOON / VOLUME 100000 FT³ / DIAMETER 65 FT / HEIGHT 90 FT / SILK 3000 PANELS / VARNISH 6 COATS / NETTING 100 KM / CAR 8 FT / VALVE 1 M² / 1851"
- **Scientific Table:** "HOUR / BAROMETER / THERMOMETER / HYGROMETER / MAGNETOMETER / ALTITUDE / DRIFT / 10:00 / 760 / 18 / 70% / 68° / 0 M / 0 KM/H / 12:00 / 720 / 12 / 60% / 68° / 1500 M / 8 KM/H / 14:00 / 730 / 10 / 65% / 68° / 1200 M / 5 KM/H"
- **Manufacturer Plates:** "COXWELL / LONDON / GREAT BALLOON 1851 / S/N 1 / AEGIS IRON MAN / S/N 1" "GREEN / VAUXHALL / NASSAU 1836 / S/N 42 / AEGIS IRON MAN / S/N 42" "PAXTON / CHATSWORTH / CRYSTAL PALACE 1851 / S/N 7 / AEGIS IRON MAN / S/N 7"

------